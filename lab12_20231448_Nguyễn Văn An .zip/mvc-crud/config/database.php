<?php
return [
'host' => '127.0.0.1',
'port' => 3307,
'dbname' => 'mvc_crud',
'username' => 'root',
'password' => ''
];