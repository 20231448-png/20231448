## MVC CRUD – PHP + PDO

### Yêu cầu
- PHP 8.x
- MySQL 8.x (cổng 3307)
- XAMPP

### Cài đặt
1. Import `database.sql`
2. Chỉnh `config/database.php` (port 3307)
3. Copy project vào `htdocs`
4. Truy cập:
   http://localhost/mvc-crud/public/index.php?c=category&a=index

