<?php
require_once __DIR__ . '/../../core/Controller.php';
require_once __DIR__ . '/../Models/Category.php';


class CategoryController extends Controller {


public function index() {
$q = $_GET['q'] ?? '';
$model = new Category();
$categories = $model->getAll($q);
$this->view('categories/index', compact('categories', 'q'));
}


public function create() {
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$name = trim($_POST['name']);
if (strlen($name) < 2) {
$error = 'Tên danh mục phải >= 2 ký tự';
} else {
(new Category())->insert($name);
header('Location: index.php?c=category&a=index');
exit;
}
}
$this->view('categories/create', compact('error'));
}


public function edit() {
$id = $_GET['id'] ?? 0;
$model = new Category();
$category = $model->findById($id);
$error = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$name = trim($_POST['name']);
if ($name === '') {
$error = 'Không được để trống';
} else {
$model->update($id, $name);
header('Location: index.php?c=category&a=index');
exit;
}
}
$this->view('categories/edit', compact('category', 'error'));
}


public function delete() {
$id = $_GET['id'] ?? 0;
(new Category())->delete($id);
header('Location: index.php?c=category&a=index');
exit;
}
}
