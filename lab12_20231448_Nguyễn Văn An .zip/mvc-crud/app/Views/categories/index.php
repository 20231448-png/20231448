<h2 style="margin-bottom:10px">📂 Quản lý danh mục</h2>
<form method="get" style="margin-bottom:15px">
<input type="hidden" name="c" value="category">
<input type="hidden" name="a" value="index">
<input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="🔍 Tìm theo tên..." style="padding:6px; width:220px">
<button style="padding:6px 10px">Tìm</button>
</form>
<a href="index.php?c=category&a=create" style="display:inline-block; margin-bottom:10px; padding:6px 10px; background:#2ecc71; color:#fff; text-decoration:none; border-radius:4px">➕ Thêm danh mục</a>

<table border="1" cellpadding="8" cellspacing="0" width="100%" style="border-collapse:collapse">
<tr style="background:#f2f2f2">
<th width="60">ID</th><th>Tên danh mục</th><th width="160">Hành động</th>
</tr>
<?php if (empty($categories)): ?>
<tr><td colspan="3" style="text-align:center">Không có dữ liệu</td></tr>
<?php endif; ?>
<?php foreach ($categories as $c): ?>
<tr>
<td><?= $c['id'] ?></td>
<td><?= htmlspecialchars($c['name']) ?></td>
<td>
<a href="index.php?c=category&a=edit&id=<?= $c['id'] ?>" style="color:#2980b9">✏️ Sửa</a> |
<a onclick="return confirm('Xóa danh mục này?')"
href="index.php?c=category&a=delete&id=<?= $c['id'] ?>" style="color:#e74c3c">🗑 Xóa</a>
</td>
</tr>
<?php endforeach ?>
</table>