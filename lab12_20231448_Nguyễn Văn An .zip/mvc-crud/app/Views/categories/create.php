<h2>Thêm danh mục</h2>
<?php if ($error): ?>
<p style="color:red"><?= $error ?></p>
<?php endif; ?>
<form method="post">
<input name="name" placeholder="Tên danh mục">
<button>Lưu</button>
</form>
<a href="index.php?c=category&a=index">Quay lại</a>