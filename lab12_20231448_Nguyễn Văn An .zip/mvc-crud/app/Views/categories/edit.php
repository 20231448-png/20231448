<h2>Sửa danh mục</h2>
<?php if ($error): ?>
<p style="color:red"><?= $error ?></p>
<?php endif; ?>
<form method="post">
<input name="name" value="<?= htmlspecialchars($category['name']) ?>">
<button>Lưu</button>
</form>
<a href="index.php?c=category&a=index">Quay lại</a>