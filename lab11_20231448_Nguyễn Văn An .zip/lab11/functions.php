<?php
session_start();

function e($s) {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function set_flash($m) {
    $_SESSION['flash'] = $m;
}

function get_flash() {
    $m = $_SESSION['flash'] ?? '';
    unset($_SESSION['flash']);
    return $m;
}
