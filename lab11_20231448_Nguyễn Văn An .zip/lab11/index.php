<?php
require 'config/db.php';

/**
 * Lấy từ khóa tìm kiếm
 */
$keyword = trim($_GET['keyword'] ?? '');

/**
 * Truy vấn dữ liệu
 */
if ($keyword === '') {
    // Không tìm kiếm → lấy tất cả
    $stmt = $pdo->query(
        "SELECT * FROM categories ORDER BY id DESC"
    );
} else {
    // Tìm theo tên danh mục
    $stmt = $pdo->prepare(
        "SELECT * FROM categories
         WHERE name LIKE :kw
         ORDER BY id DESC"
    );
    $stmt->execute([
        ':kw' => "%$keyword%"
    ]);
}

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh mục</title>
    <style>
        body {
            font-family: Arial;
            margin: 30px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background: #f2f2f2;
        }
        form {
            margin-bottom: 15px;
        }
        input[type=text] {
            padding: 6px;
            width: 250px;
        }
        button {
            padding: 6px 10px;
        }
        a {
            text-decoration: none;
        }
    </style>
</head>
<body>

<h2>DANH MỤC</h2>

<form method="get">
    <input
        type="text"
        name="keyword"
        placeholder="Nhập tên danh mục..."
        value="<?= htmlspecialchars($keyword) ?>"
    >
    <button type="submit">Tìm kiếm</button>
    <a href="create.php">➕ Thêm mới</a>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Tên danh mục</th>
        <th>Slug</th>
        <th>Trạng thái</th>
        <th>Hành động</th>
    </tr>

    <?php if (empty($rows)): ?>
        <tr>
            <td colspan="5">Không có dữ liệu</td>
        </tr>
    <?php else: ?>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['slug']) ?></td>
                <td><?= $row['status'] ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>">Sửa</a> |
                    <a href="delete.php?id=<?= $row['id'] ?>"
                       onclick="return confirm('Bạn có chắc muốn xóa?')">
                        Xóa
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>

</table>

</body>
</html>
