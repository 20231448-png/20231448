<?php
require 'config/db.php';
require 'flash.php';

$errors = [];
$name = $slug = $description = '';
$status = '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? '1';

    // Validate tên
    if ($name === '' || mb_strlen($name) < 3) {
        $errors['name'] = 'Tên danh mục phải có ít nhất 3 ký tự';
    }

    // Validate slug
    if ($slug === '') {
        $errors['slug'] = 'Slug không được để trống';
    } elseif (!preg_match('/^[a-z0-9-]+$/', $slug)) {
        $errors['slug'] = 'Slug chỉ được chứa chữ thường, số và dấu -';
    } else {
        // Kiểm tra trùng slug
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM categories WHERE slug = ?"
        );
        $stmt->execute([$slug]);
        if ($stmt->fetchColumn() > 0) {
            $errors['slug'] = 'Slug đã tồn tại';
        }
    }

    // Validate trạng thái
    if (!in_array($status, ['0', '1'])) {
        $errors['status'] = 'Trạng thái không hợp lệ';
    }

    // Nếu không có lỗi → insert
    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "INSERT INTO categories (name, slug, description, status)
             VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$name, $slug, $description, $status]);

        set_flash('Thêm danh mục thành công');
        header('Location: index.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm danh mục</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f6fa;
        }
        .container {
            width: 500px;
            margin: 40px auto;
            background: #fff;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
        }
        h2 {
            text-align: center;
        }
        label {
            font-weight: bold;
        }
        input, textarea, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
        }
        .error {
            color: red;
            font-size: 13px;
        }
        button {
            padding: 8px 14px;
        }
        a {
            margin-left: 10px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>THÊM DANH MỤC</h2>

    <form method="post">

        <label>Tên danh mục</label>
        <input type="text" name="name"
               value="<?= htmlspecialchars($name) ?>">
        <div class="error"><?= $errors['name'] ?? '' ?></div>

        <label>Slug</label>
        <input type="text" name="slug"
               placeholder="vi-du-slug"
               value="<?= htmlspecialchars($slug) ?>">
        <div class="error"><?= $errors['slug'] ?? '' ?></div>

        <label>Mô tả</label>
        <textarea name="description" rows="4"><?= htmlspecialchars($description) ?></textarea>

        <label>Trạng thái</label>
        <select name="status">
            <option value="1" <?= $status === '1' ? 'selected' : '' ?>>
                Hoạt động
            </option>
            <option value="0" <?= $status === '0' ? 'selected' : '' ?>>
                Không hoạt động
            </option>
        </select>

        <br>
        <button type="submit">💾 Lưu</button>
        <a href="index.php">⬅ Quay lại</a>
    </form>
</div>

</body>
</html>
