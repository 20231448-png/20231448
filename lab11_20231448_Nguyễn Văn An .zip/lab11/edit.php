<?php
require 'config/db.php';
require 'flash.php';

$id = (int)($_GET['id'] ?? 0);

// Lấy dữ liệu cũ
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row) {
    die('Danh mục không tồn tại');
}

$errors = [];
$name = $row['name'];
$slug = $row['slug'];
$description = $row['description'];
$status = (string)$row['status'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? '1';

    // Validate tên
    if ($name === '' || mb_strlen($name) < 3) {
        $errors['name'] = 'Tên danh mục phải có ít nhất 3 ký tự';
    }

    // Validate slug
    if ($slug === '') {
        $errors['slug'] = 'Slug không được để trống';
    } elseif (!preg_match('/^[a-z0-9-]+$/', $slug)) {
        $errors['slug'] = 'Slug chỉ được chứa chữ thường, số và dấu -';
    } else {
        // Kiểm tra trùng slug (trừ chính nó)
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM categories
             WHERE slug = ? AND id <> ?"
        );
        $stmt->execute([$slug, $id]);
        if ($stmt->fetchColumn() > 0) {
            $errors['slug'] = 'Slug đã tồn tại';
        }
    }

    // Validate trạng thái
    if (!in_array($status, ['0', '1'])) {
        $errors['status'] = 'Trạng thái không hợp lệ';
    }

    // Cập nhật
    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "UPDATE categories
             SET name = ?, slug = ?, description = ?, status = ?
             WHERE id = ?"
        );
        $stmt->execute([$name, $slug, $description, $status, $id]);

        set_flash('Cập nhật danh mục thành công');
        header('Location: index.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa danh mục</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f6fa;
        }
        .container {
            width: 500px;
            margin: 40px auto;
            background: #fff;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
        }
        h2 {
            text-align: center;
        }
        label {
            font-weight: bold;
        }
        input, textarea, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
        }
        .error {
            color: red;
            font-size: 13px;
        }
        button {
            padding: 8px 14px;
        }
        a {
            margin-left: 10px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>SỬA DANH MỤC</h2>

    <form method="post">

        <label>Tên danh mục</label>
        <input type="text" name="name"
               value="<?= htmlspecialchars($name) ?>">
        <div class="error"><?= $errors['name'] ?? '' ?></div>

        <label>Slug</label>
        <input type="text" name="slug"
               value="<?= htmlspecialchars($slug) ?>">
        <div class="error"><?= $errors['slug'] ?? '' ?></div>

        <label>Mô tả</label>
        <textarea name="description" rows="4"><?= htmlspecialchars($description) ?></textarea>

        <label>Trạng thái</label>
        <select name="status">
            <option value="1" <?= $status === '1' ? 'selected' : '' ?>>
                Hoạt động
            </option>
            <option value="0" <?= $status === '0' ? 'selected' : '' ?>>
                Không hoạt động
            </option>
        </select>

        <br>
        <button type="submit">💾 Cập nhật</button>
        <a href="index.php">⬅ Quay lại</a>
    </form>
</div>

</body>
</html>
