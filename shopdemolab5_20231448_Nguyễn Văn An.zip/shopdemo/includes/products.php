<?php
return [
    1 => [
        'name'  => 'Áo thun',
        'price' => 120000
    ],
    2 => [
        'name'  => 'Quần jean',
        'price' => 250000
    ],
    3 => [
        'name'  => 'Giày sneaker',
        'price' => 500000
    ],
];
