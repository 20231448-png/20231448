<?php
echo "<h1>LAB 02 - OK</h1>";
echo "<p>it3220.local/lab02</p>";
