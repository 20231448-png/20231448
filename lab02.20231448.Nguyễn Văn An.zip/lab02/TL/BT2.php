<?php
// Khai báo các kiểu dữ liệu
$intVar    = 10;            // integer
$floatVar  = 3.14;          // float
$stringVar = "Hello PHP";   // string
$boolVar   = true;          // boolean
$arrayVar  = [1, 2, 3];     // array

// Output
echo "<h3>Kiểu dữ liệu trong PHP</h3>";
var_dump($intVar);
echo "<br>";
var_dump($floatVar);
echo "<br>";
var_dump($stringVar);
echo "<br>";
var_dump($boolVar);
echo "<br>";
var_dump($arrayVar);
?>
