<?php
/*
Input:
- a: số thứ nhất
- b: số thứ hai
- op: phép toán (+, -, *, /)

Output:
- Kết quả phép tính
*/
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BT4 - Máy tính</title>
</head>
<body>

<h3>Máy tính cơ bản</h3>

<form method="get">
    Số a:
    <input type="number" name="a" step="any" required>
    <br><br>

    Số b:
    <input type="number" name="b" step="any" required>
    <br><br>

    Phép toán:
    <select name="op">
        <option value="+">Cộng</option>
        <option value="-">Trừ</option>
        <option value="*">Nhân</option>
        <option value="/">Chia</option>
    </select>
    <br><br>

    <button type="submit">Tính</button>
</form>

<?php
if (isset($_GET['a'], $_GET['b'], $_GET['op'])) {
    $a = $_GET['a'];
    $b = $_GET['b'];
    $op = $_GET['op'];

    switch ($op) {
        case '+':
            $result = $a + $b;
            break;
        case '-':
            $result = $a - $b;
            break;
        case '*':
            $result = $a * $b;
            break;
        case '/':
            $result = ($b != 0) ? $a / $b : "Không chia được cho 0";
            break;
        default:
            $result = "Phép toán không hợp lệ";
    }

    echo "<hr>";
    echo "a = $a <br>";
    echo "b = $b <br>";
    echo "Phép toán = $op <br>";
    echo "Kết quả = $result <br>";
}
?>

</body>
</html>
