<?php
/*
Input:
- r: bán kính hình tròn (number)

Output:
- Chu vi
- Diện tích hình tròn
*/
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BT3 - Hình tròn</title>
</head>
<body>

<h3>Tính chu vi & diện tích hình tròn</h3>

<form method="post">
    Bán kính:
    <input type="number" name="r" step="any" required>
    <br><br>
    <button type="submit">Tính</button>
</form>

<?php
if (isset($_POST['r'])) {
    $r = $_POST['r'];
    $pi = 3.14;

    $chuVi = 2 * $pi * $r;
    $dienTich = $pi * $r * $r;

    echo "<hr>";
    echo "Bán kính: $r <br>";
    echo "Chu vi: $chuVi <br>";
    echo "Diện tích: $dienTich <br>";
}
?>

</body>
</html>
