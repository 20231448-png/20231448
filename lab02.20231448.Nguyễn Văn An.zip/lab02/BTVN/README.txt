HỌ TÊN : Nguyễn Phương Thảo
MSSV   : 20230762
LỚP    : IT14.2
Bật Apache trong XAMPP, sau đó mở trình duyệt và truy cập:
Bài 1 – PHP cơ bản
- Hello PHP:
  http://it3220.local/Lab02/BTVN/ex01/hello.php
- PHP Info:
  http://it3220.local/Lab02/BTVN/ex01/info.php
Bài 2 – Biến, hằng, kiểu dữ liệu
- Variables:
  http://it3220.local/Lab02/BTVN/ex02/variables.php
Bài 3 – Toán tử và nối chuỗi
- Calc basic:
  http://it3220.local/Lab02/BTVN/ex03/calc_basic.php
Bài 4 – Máy tính dùng GET
- Calc get:
  http://it3220.local/Lab02/BTVN/ex04/calc_get.php?a=7&b=10&op=add
  http://it3220.local/Lab02/BTVN/ex04/calc_get.php?a=7&b=10&op=sub
  http://it3220.local/Lab02/BTVN/ex04/calc_get.php?a=7&b=10&op=mul
  http://it3220.local/Lab02/BTVN/ex04/calc_get.php?a=7&b=10&op=div
Bài 5 – BMI (GET Form)
- BMI Form:
  http://it3220.local/Lab02/BTVN/ex05/bmi_form.php
3. GHI CHÚ / KHÓ KHĂN
- Ban đầu gặp lỗi Undefined index khi chưa kiểm tra isset().
- Đã xử lý lỗi chia cho 0 và kiểm tra dữ liệu đầu vào.