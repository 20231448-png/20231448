<?php
// 2. Tạo ex01/info.php hiển thị thông tin PHP bằng phpinfo().
phpinfo();
?>