<?php
// 1. Tạo ex01/hello.php hiển thị: Hello PHP!, họ tên – MSSV – lớp, và ngày giờ hiện tại (date()).
echo "Hello PHP!<br>";
echo "Họ tên: Nguyễn Văn An<br>";
echo "MSSV: 20231448<br>";
echo "Lớp: IT14.04<br>";
echo "Ngày giờ hiện tại: " . date("d/m/Y H:i:s");
?>