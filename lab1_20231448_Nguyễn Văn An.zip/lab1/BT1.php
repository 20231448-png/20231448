<?php
// Input
$name  = "Nguyễn Văn An";
$class = "CNTT.14.4";
$email = "20231448@eaut.edu.vn";
$sdt ="0389257126";

// Output
echo "<h3>Thông tin cá nhân</h3>";
echo "Họ tên: $name <br>";
echo "Lớp: $class <br>";
echo "Email: $email <br>";
echo "sdt : $sdt <br>";
?>
