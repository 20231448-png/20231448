<?php
if (isset($_GET['name']) && isset($_GET['age'])) {
    $name = htmlspecialchars($_GET['name']);
    $age  = htmlspecialchars($_GET['age']);

    echo "<h2>Xin chào $name, tuổi: $age</h2>";
} else {
    echo "<h3>Thiếu tham số!</h3>";
    echo "<p>Vui lòng truy cập theo mẫu:</p>";
    echo "<code>get_demo.php?name=An&age=20</code>";
}
?>
