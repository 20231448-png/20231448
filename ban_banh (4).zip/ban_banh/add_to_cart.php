<?php
require 'db.php';

$cake_id = $_POST['cake_id'];
$qty     = $_POST['quantity'];
$session = session_id();

/* TÌM CART */
$stmt = $pdo->prepare("SELECT id FROM cart WHERE session_id = ?");
$stmt->execute([$session]);
$cart = $stmt->fetch();

/* NẾU CHƯA CÓ CART → TẠO */
if (!$cart) {
    $pdo->prepare("INSERT INTO cart(session_id) VALUES (?)")
        ->execute([$session]);
    $cart_id = $pdo->lastInsertId();
} else {
    $cart_id = $cart['id'];
}

/* KIỂM TRA SP ĐÃ CÓ CHƯA */
$stmt = $pdo->prepare(
    "SELECT id, quantity FROM cart_items 
     WHERE cart_id = ? AND cake_id = ?"
);
$stmt->execute([$cart_id, $cake_id]);
$item = $stmt->fetch();

if ($item) {
    $pdo->prepare(
        "UPDATE cart_items SET quantity = quantity + ?
         WHERE id = ?"
    )->execute([$qty, $item['id']]);
} else {
    $pdo->prepare(
        "INSERT INTO cart_items(cart_id, cake_id, quantity)
         VALUES (?,?,?)"
    )->execute([$cart_id, $cake_id, $qty]);
}

echo "ok";
