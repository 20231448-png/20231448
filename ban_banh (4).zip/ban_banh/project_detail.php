<?php
require 'db.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->execute([$id]);
$project = $stmt->fetch();

if (!$project) {
    header("Location: projects.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($project['title']) ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="project-detail container">
    <div class="detail-box">

        <!-- HÌNH ẢNH -->
        <div class="detail-image">
            <img src="images/<?= htmlspecialchars($project['image']) ?>" 
                 alt="<?= htmlspecialchars($project['title']) ?>">
        </div>

        <!-- NỘI DUNG -->
        <div class="detail-content">
            <h1 class="detail-title">
                <?= htmlspecialchars($project['title']) ?>
            </h1>

            <p class="detail-date">
                📅 Ngày tổ chức: 
                <strong><?= date('d/m/Y', strtotime($project['event_date'])) ?></strong>
            </p>

            <div class="detail-desc">
                <?= nl2br(htmlspecialchars($project['description'])) ?>
            </div>

            <div class="detail-actions">
                <a href="projects.php" class="btn">← Quay lại danh sách dự án</a>
            </div>
        </div>

    </div>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
