<?php
session_start();
require 'db.php';

$id  = (int)($_POST['id'] ?? 0);
$qty = (int)($_POST['qty'] ?? 1);

if ($id <= 0) {
    die("ID không hợp lệ");
}

/* Lấy sản phẩm */
$stmt = $pdo->prepare("SELECT * FROM cakes WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    die("Sản phẩm không tồn tại");
}

/* Khởi tạo giỏ */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* Nếu đã có → cộng số lượng */
if (isset($_SESSION['cart'][$id])) {
    $_SESSION['cart'][$id]['qty'] += $qty;
} else {
    $_SESSION['cart'][$id] = [
        'id'    => $product['id'],
        'name'  => $product['name'],
        'price' => $product['price'],
        'qty'   => $qty,
        'image' => $product['image']
    ];
}

header("Location: cart.php");
exit;
