<?php
require 'db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("
    SELECT title, content, image, author, created_at
    FROM news
    WHERE id = ?
");
$stmt->execute([$id]);

$item = $stmt->fetch();

if (!$item) {
    die("❌ Bài viết không tồn tại");
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($item['title']) ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<!-- ===== CHI TIẾT TIN TỨC ===== -->
<section class="news-detail">
    <div class="container">

        <h1 class="detail-title">
            <?= htmlspecialchars($item['title']) ?>
        </h1>

        <p class="detail-meta">
            📅 <?= date('d/m/Y', strtotime($item['created_at'])) ?>
            &nbsp; • &nbsp;
            ✍ <?= htmlspecialchars($item['author']) ?>
        </p>

        <img
            src="images/<?= htmlspecialchars($item['image']) ?>"
            alt=""
            class="detail-img"
        >

        <div class="detail-content">
            <?= nl2br($item['content']) ?>
        </div>

        <div class="detail-back">
            <a href="news.php" class="btn">← Quay lại tin tức</a>
        </div>

    </div>
</section>

<?php include 'footer.php'; ?>
</body>
</html>
