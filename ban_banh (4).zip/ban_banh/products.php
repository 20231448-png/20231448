<?php
require 'db.php';

/* Lấy danh mục */
$cats = $pdo->query("SELECT * FROM categories")->fetchAll();

/* Lấy loại đang chọn */
$catId = $_GET['cat'] ?? 0;

if ($catId) {
    $stmt = $pdo->prepare("
        SELECT cakes.*, categories.name AS cat_name
        FROM cakes 
        JOIN categories ON cakes.category_id = categories.id
        WHERE category_id = ?
    ");
    $stmt->execute([$catId]);
} else {
    $stmt = $pdo->query("
        SELECT cakes.*, categories.name AS cat_name
        FROM cakes 
        JOIN categories ON cakes.category_id = categories.id
    ");
}

$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Sản phẩm | Bài Tập Bakery</title>
<link rel="stylesheet" href="css/style.css">
<style>
.category-menu{
    display:flex;
    gap:15px;
    margin-bottom:20px;
}
.category-menu a{
    padding:8px 15px;
    border-radius:20px;
    background:#eee;
}
.category-menu a.active{
    background:#f4a261;
    color:white;
}
.product-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
    gap:20px;
}
.product-card{
    border:1px solid #eee;
    padding:15px;
    border-radius:10px;
    text-align:center;
}
.product-card img{
    width:100%;
    height:180px;
    object-fit:cover;
}
</style>
</head>
<body>

<?php include 'header.php'; ?>

<section class="container">
<h2>🎂 SẢN PHẨM</h2>

<!-- MENU LOẠI -->
<div class="category-menu">
    <a href="products.php" class="<?= $catId==0?'active':'' ?>">Tất cả</a>
    <?php foreach($cats as $c): ?>
        <a href="products.php?cat=<?= $c['id'] ?>"
           class="<?= $catId==$c['id']?'active':'' ?>">
           <?= htmlspecialchars($c['name']) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- DANH SÁCH -->
<div class="product-grid">
<?php foreach($products as $p): ?>
    <div class="product-card">
        <img src="images/<?= $p['image'] ?>">
        <h3><?= htmlspecialchars($p['name']) ?></h3>
        <p class="price"><?= number_format($p['price']) ?> đ</p>
        <a href="product.php?id=<?= $p['id'] ?>" class="btn">
            Xem chi tiết
        </a>
    </div>
<?php endforeach; ?>
</div>
</section>

<?php include 'footer.php'; ?>
</body>
</html>
