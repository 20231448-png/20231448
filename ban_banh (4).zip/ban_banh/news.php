<?php
require 'db.php';

/* Lấy danh sách tin tức */
$news = $pdo->query(
    "SELECT * FROM news ORDER BY created_at DESC"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tin Tức | Anh Hòa Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<!-- ===== THÔNG BÁO ===== -->
<p style="text-align:center; margin:30px 0; font-style:italic; color:#666;">
    Website này được xây dựng nhằm phục vụ mục đích học tập và bài thi.
    Các nội dung hiển thị chỉ mang tính minh họa, không áp dụng cho hoạt động mua bán thực tế.
</p>

<!-- ===== TIN TỨC ===== -->
<section class="news">
    <div class="container">

        <h2 class="section-title">TIN TỨC</h2>
        <p class="section-sub">NỔI BẬT NHẤT TRONG TUẦN</p>

        <?php if (empty($news)): ?>
            <p style="text-align:center;">Chưa có tin tức nào 😢</p>
        <?php else: ?>

        <div class="news-grid">
            <?php foreach ($news as $item): ?>
            <div class="news-card">

                <div class="news-img">
                    <img src="images/<?= htmlspecialchars($item['image']) ?>" alt="">
                    <span class="news-date">
                        <?= date('d', strtotime($item['created_at'])) ?><br>
                        <?= date('m/Y', strtotime($item['created_at'])) ?>
                    </span>
                </div>

                <h3><?= htmlspecialchars($item['title']) ?></h3>

                <p class="news-meta">
                    💬 0 bình luận • 🌸 <?= htmlspecialchars($item['author']) ?>
                </p>

                <p class="news-desc">
                    <?= mb_substr(strip_tags($item['content']), 0, 100) ?>...
                </p>

                <!-- ===== NÚT CĂN GIỮA ===== -->
                <div style="text-align:center; padding-bottom:20px;">
                    <a href="news_detail.php?id=<?= $item['id'] ?>" class="news-btn">
                        Xem chi tiết
                    </a>
                </div>

            </div>
            <?php endforeach; ?>
        </div>

        <?php endif; ?>

    </div>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
