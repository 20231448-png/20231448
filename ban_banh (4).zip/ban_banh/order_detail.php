<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$order_id = (int)$_GET['id'];
$user_id  = $_SESSION['user']['id'];

// Lấy order
$stmt = $pdo->prepare("
    SELECT * FROM orders
    WHERE id = :id AND user_id = :user_id
");
$stmt->execute([
    'id' => $order_id,
    'user_id' => $user_id
]);
$order = $stmt->fetch();

if (!$order) {
    die("Đơn hàng không tồn tại");
}

// Lấy sản phẩm
$stmt = $pdo->prepare("
    SELECT oi.*, c.name, c.image
    FROM order_items oi
    JOIN cakes c ON oi.cake_id = c.id
    WHERE oi.order_id = :order_id
");
$stmt->execute(['order_id' => $order_id]);
$items = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chi tiết đơn hàng</title>
<link rel="stylesheet" href="css/style.css">
<style>
.detail-box{
    max-width:900px;
    margin:40px auto;
}
.item{
    display:flex;
    gap:14px;
    margin-bottom:14px;
}
.item img{
    width:90px;
    height:90px;
    object-fit:cover;
    border-radius:10px;
}
</style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="detail-box">
    <h2>🧾 Chi tiết đơn #<?= $order['id'] ?></h2>
    <p>Trạng thái: <strong><?= $order['status'] ?></strong></p>

    <hr>

    <?php foreach ($items as $i): ?>
        <div class="item">
            <img src="images/<?= $i['image'] ?>">
            <div>
                <strong><?= $i['name'] ?></strong><br>
                SL: <?= $i['qty'] ?><br>
                Giá: <?= number_format($i['price']) ?> đ
            </div>
        </div>
    <?php endforeach; ?>

    <hr>
    <h3>Tổng tiền: <?= number_format($order['total']) ?> đ</h3>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
