<?php
session_start();
$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Giỏ hàng | Bài Tập Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="cart container">
    <div style="margin-top:20px;">
    <h2>GIỎ HÀNG CỦA BẠN</h2>

<?php if (empty($cart)): ?>
    <p>Giỏ hàng đang trống 😢</p>
<?php else: ?>

<table class="cart-table">
    <tr>
        <th>Sản phẩm</th>
        <th>Giá</th>
        <th>Số lượng</th>
        <th>Tạm tính</th>
        <th></th>
    </tr>

<?php foreach ($cart as $item): 
    $sub = $item['price'] * $item['qty'];
    $total += $sub;
?>
<tr>
    <td>
        <img src="images/<?= htmlspecialchars($item['image']) ?>" width="60">
        <?= htmlspecialchars($item['name']) ?>
    </td>

    <td><?= number_format($item['price']) ?> đ</td>

    <td>
        <form action="cart_update.php" method="post">
            <input type="hidden" name="id" value="<?= $item['id'] ?>">

            <div style="display:flex; align-items:center; justify-content:center; gap:6px;">
                <input type="number" name="qty" value="<?= $item['qty'] ?>" min="1">
                <button type="submit">Cập nhật</button>
            </div>
        </form>
    </td>

    <td><?= number_format($sub) ?> đ</td>

    <td style="text-align:center;">
        <a href="cart_delete.php?id=<?= $item['id'] ?>"
           onclick="return confirm('Xóa sản phẩm?')"
           style="font-size:18px;">❌</a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<!-- ===== TỔNG TIỀN + THANH TOÁN ===== -->
<div style="margin-top:25px; text-align:right;">
    <h3>
        Tổng tiền:
        <span class="price"><?= number_format($total) ?> đ</span>
    </h3>

    <!-- ĐẨY NÚT XUỐNG THÊM -->
    <div style="margin-top:20px;">
        <a href="checkout.php" class="btn-buy">TIẾN HÀNH THANH TOÁN</a>
    </div>
</div>

<?php endif; ?>

</section>

<?php include 'footer.php'; ?>

</body>
</html>
