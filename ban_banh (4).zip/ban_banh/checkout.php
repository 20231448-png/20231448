<?php
session_start();
$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: cart.php");
    exit;
}

$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['qty'];
}
$shipFee = 30000;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thanh toán | Bài tập Bakery</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        /* ===== CHECKOUT ===== */
        .checkout-container{
            max-width:1200px;
            margin:40px auto;
            padding:0 20px;
        }
        .checkout-title{
            text-align:center;
            font-size:28px;
            margin-bottom:30px;
            color:#6b2c2c;
        }
        .checkout-box{
            display:grid;
            grid-template-columns: 1.2fr 1fr;
            gap:30px;
        }
        .checkout-card{
            background:#fff;
            padding:24px;
            border-radius:16px;
            box-shadow:0 8px 25px rgba(0,0,0,0.08);
        }
        .checkout-card h3{
            margin-bottom:16px;
            color:#6b2c2c;
        }
        .checkout-card input,
        .checkout-card textarea,
        .checkout-card select{
            width:100%;
            padding:12px 14px;
            margin-bottom:14px;
            border-radius:8px;
            border:1px solid #ddd;
            font-size:15px;
        }
        .checkout-card input:focus,
        .checkout-card textarea:focus,
        .checkout-card select:focus{
            outline:none;
            border-color:#6b2c2c;
            box-shadow:0 0 0 2px rgba(107,44,44,0.15);
        }
        .order-summary p{
            display:flex;
            justify-content:space-between;
            margin:10px 0;
        }
        .order-summary hr{
            border:none;
            border-top:1px dashed #ddd;
            margin:16px 0;
        }
        .order-summary .total{
            font-size:18px;
            font-weight:bold;
            color:#d40000;
        }
        .payment-box{
            background:#fff8e1;
            padding:14px;
            border-radius:10px;
            margin-top:10px;
            font-size:14px;
            display:none;
        }
        .btn-buy{
            width:100%;
            padding:14px;
            margin-top:20px;
            background:#8bc34a;
            color:#fff;
            border:none;
            border-radius:10px;
            font-size:16px;
            font-weight:bold;
            cursor:pointer;
        }
        .btn-buy:hover{
            background:#76a93a;
        }
        @media(max-width:768px){
            .checkout-box{grid-template-columns:1fr;}
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<section class="checkout-container">
    <h2 class="checkout-title">THANH TOÁN</h2>

    <form action="checkout_process.php" method="post">
        <div class="checkout-box">

            <!-- THÔNG TIN KHÁCH -->
            <div class="checkout-card">
                <h3>Thông tin khách hàng</h3>

                <input type="text" name="name" placeholder="Họ và tên" required>
                <input type="text" name="phone" placeholder="Số điện thoại" required>

                <select name="delivery" id="delivery" onchange="toggleShip()" required>
                    <option value="store">🏪 Lấy tại quầy</option>
                    <option value="ship">🚚 Giao hàng tận nơi</option>
                </select>

                <div id="addressBox" style="display:none">
                    <textarea name="address" placeholder="Địa chỉ giao hàng"></textarea>
                </div>

                <div class="payment-box" id="codBox">
                    ✔ Thanh toán khi nhận hàng (COD)<br>
                    ✔ Phí ship: <strong><?= number_format($shipFee) ?> đ</strong>
                </div>
            </div>

            <!-- ĐƠN HÀNG -->
            <div class="checkout-card order-summary">
                <h3>Đơn hàng</h3>

                <?php foreach ($cart as $item): ?>
                <p>
                    <span><?= htmlspecialchars($item['name']) ?> × <?= $item['qty'] ?></span>
                    <span><?= number_format($item['price'] * $item['qty']) ?> đ</span>
                </p>
                <?php endforeach; ?>

                <hr>

                <p>
                    <strong>Tạm tính</strong>
                    <strong><?= number_format($total) ?> đ</strong>
                </p>

                <p id="shipRow" style="display:none">
                    <span>Phí ship</span>
                    <span><?= number_format($shipFee) ?> đ</span>
                </p>

                <p class="total">
                    <span>Tổng tiền</span>
                    <span id="grandTotal"><?= number_format($total) ?> đ</span>
                </p>

                <input type="hidden" name="total" id="totalInput" value="<?= $total ?>">

                <button class="btn-buy">
                    XÁC NHẬN ĐẶT HÀNG
                </button>
            </div>

        </div>
    </form>
</section>

<?php include 'footer.php'; ?>

<script>
function toggleShip(){
    const delivery = document.getElementById('delivery').value;
    const addressBox = document.getElementById('addressBox');
    const shipRow = document.getElementById('shipRow');
    const codBox = document.getElementById('codBox');
    const total = <?= $total ?>;
    const shipFee = <?= $shipFee ?>;

    if(delivery === 'ship'){
        addressBox.style.display = 'block';
        shipRow.style.display = 'flex';
        codBox.style.display = 'block';
        document.getElementById('grandTotal').innerText =
            (total + shipFee).toLocaleString() + ' đ';
        document.getElementById('totalInput').value = total + shipFee;
    }else{
        addressBox.style.display = 'none';
        shipRow.style.display = 'none';
        codBox.style.display = 'none';
        document.getElementById('grandTotal').innerText =
            total.toLocaleString() + ' đ';
        document.getElementById('totalInput').value = total;
    }
}
</script>

</body>
</html>
