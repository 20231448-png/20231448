<?php
$host = '127.0.0.1';   // hoặc 'localhost'
$db   = 'ban_banh';    // đúng tên CSDL trong phpMyAdmin
$user = 'root';        // XAMPP/WAMP mặc định
$pass = '';            // XAMPP thường để trống
$port = 3307;          // cổng MySQL của bạn

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
    // echo "Kết nối OK";
} catch (PDOException $e) {
    die("❌ Lỗi kết nối CSDL: " . $e->getMessage());
}
?>
