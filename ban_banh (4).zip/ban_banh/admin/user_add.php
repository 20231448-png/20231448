<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $fullname = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $role     = $_POST['role'];

    if ($username === '' || $email === '' || $password === '') {
        $error = 'Vui lòng nhập đầy đủ thông tin';
    } else {
        // check trùng username
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $check->execute([$username]);

        if ($check->fetch()) {
            $error = 'Username đã tồn tại';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO users (username, fullname, email, password, role)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $username,
                $fullname,
                $email,
                $hash,
                $role
            ]);

            header("Location: users.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm tài khoản | Admin</title>

    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include '../header.php'; ?>

<div class="admin-container" style="max-width:720px">
    <div class="admin-title">👤 Thêm tài khoản mới</div>

    <?php if ($error): ?>
        <div class="alert-error"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" class="admin-form">

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="vd: user01" required>
        </div>

        <div class="form-group">
            <label>Họ tên</label>
            <input type="text" name="fullname" placeholder="Nguyễn Văn A">
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="email@gmail.com" required>
        </div>

        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="password" required>
        </div>

        <div class="form-group">
            <label>Quyền</label>
            <select name="role">
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">💾 Tạo tài khoản</button>
            <a href="users.php" class="btn btn-back">← Quay lại</a>
        </div>
    </form>
</div>

<?php include '../footer.php'; ?>

</body>
</html>
