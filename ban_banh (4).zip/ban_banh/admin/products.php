<?php
require_once __DIR__ . '/../db.php';

$products = $pdo->query("
    SELECT cakes.*, categories.name AS category_name
    FROM cakes
    JOIN categories ON cakes.category_id = categories.id
    ORDER BY cakes.id DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý sản phẩm | Admin</title>

    <!-- CSS -->
    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<!-- ===== ADMIN WRAPPER ===== -->
<section class="admin-wrapper">
    <div class="admin-box">

        <!-- HEADER -->
        <div class="admin-header">
            <h1>📦 Quản lý sản phẩm</h1>
            <a href="product_add.php" class="btn-add">➕ Thêm sản phẩm</a>
        </div>

        <!-- TABLE -->
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ảnh</th>
                        <th>Tên</th>
                        <th>Danh mục</th>
                        <th>Giá</th>
                        <th width="120">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                    <tr>
                        <td><?= $p['id'] ?></td>
                        <td>
                            <img src="/ban_banh/images/<?= htmlspecialchars($p['image']) ?>" class="thumb">
                        </td>
                        <td><?= htmlspecialchars($p['name']) ?></td>
                        <td><?= htmlspecialchars($p['category_name']) ?></td>
                        <td><?= number_format($p['price']) ?> đ</td>
                        <td class="action-col">
                            <a href="product_edit.php?id=<?= $p['id'] ?>" class="btn-edit">✏️</a>
                            <a href="product_delete.php?id=<?= $p['id'] ?>"
                               onclick="return confirm('Xóa sản phẩm?')"
                               class="btn-delete">🗑</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>
</section>

<?php include_once __DIR__ . '/../footer.php'; ?>
</body>
</html>
