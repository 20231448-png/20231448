<?php
session_start();
require 'db.php';

$total = 0;
foreach ($_SESSION['cart'] as $id => $qty) {
    $stmt = $pdo->prepare("SELECT price FROM cakes WHERE id=?");
    $stmt->execute([$id]);
    $price = $stmt->fetchColumn();
    $total += $price * $qty;
}

$stmt = $pdo->prepare(
    "INSERT INTO orders(customer_name,phone,address,total)
     VALUES (?,?,?,?)"
);
$stmt->execute([
    $_POST['name'],
    $_POST['phone'],
    $_POST['address'],
    $total
]);

$order_id = $pdo->lastInsertId();

foreach ($_SESSION['cart'] as $id => $qty) {
    $stmt = $pdo->prepare(
        "INSERT INTO order_items(order_id,cake_id,qty,price)
         VALUES (?,?,?,?)"
    );
    $stmt->execute([$order_id, $id, $qty, $price]);
}

unset($_SESSION['cart']);
header("Location: success.php");
