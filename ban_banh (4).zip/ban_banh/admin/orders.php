<?php
session_start();
require '../db.php';

/* CHECK ADMIN */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

/* ===== SQL ĐÚNG ===== */
$sql = "
SELECT 
    o.id,
    o.delivery_method,
    o.total,
    o.ship_fee,
    o.status,
    o.created_at,
    COALESCE(o.customer_name, u.fullname) AS display_name
FROM orders o
LEFT JOIN users u ON o.user_id = u.id
ORDER BY o.created_at DESC
";

$orders = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý đơn hàng | Admin</title>

    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">

    <style>
        .admin-container {
            max-width: 1300px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,.08);
        }
        .admin-title {
            font-size: 30px;
            font-weight: bold;
            margin-bottom: 25px;
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 16px;
        }
        .admin-table th,
        .admin-table td {
            padding: 14px 12px;
            border-bottom: 1px solid #e5e5e5;
            text-align: center;
        }
        .admin-table th {
            background: #f8f8f8;
            font-size: 17px;
            text-transform: uppercase;
        }
        .admin-table tr:hover {
            background: #fafafa;
        }
        .price {
            font-weight: bold;
            color: #e67e22;
        }
        .status {
            font-weight: bold;
        }
        .btn-edit,
        .btn-delete {
            padding: 8px 14px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            margin: 2px;
            display: inline-block;
        }
        .btn-edit {
            background: #3498db;
            color: #fff;
        }
        .btn-delete {
            background: #e74c3c;
            color: #fff;
        }
    </style>
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<div class="admin-container">
    <div class="admin-title">📦 Quản lý đơn hàng</div>

    <table class="admin-table">
        <tr>
            <th>ID</th>
            <th>Khách hàng</th>
            <th>Hình thức</th>
            <th>Tổng tiền</th>
            <th>Trạng thái</th>
            <th>Ngày đặt</th>
            <th>Thao tác</th>
        </tr>

        <?php foreach ($orders as $o): ?>
        <tr>
            <td>#<?= $o['id'] ?></td>
            <td><?= htmlspecialchars($o['display_name'] ?: 'Khách vãng lai') ?></td>
            <td><?= ucfirst($o['delivery_method']) ?></td>
            <td class="price">
                <?= number_format($o['total'] + $o['ship_fee']) ?> đ
            </td>
            <td class="status">
                <?php
                switch ($o['status']) {
                    case 'pending': echo '⏳ Chờ xử lý'; break;
                    case 'confirmed': echo '✅ Đã xác nhận'; break;
                    case 'shipping': echo '🚚 Đang giao'; break;
                    case 'done': echo '✔ Hoàn thành'; break;
                    case 'cancel': echo '❌ Đã hủy'; break;
                    default: echo htmlspecialchars($o['status']);
                }
                ?>
            </td>
            <td><?= date('d/m/Y H:i', strtotime($o['created_at'])) ?></td>
            <td>
                <a href="order_edit.php?id=<?= $o['id'] ?>" class="btn-edit">Sửa</a>
                <a href="order_delete.php?id=<?= $o['id'] ?>"
                   class="btn-delete"
                   onclick="return confirm('Xóa đơn hàng này?')">
                   Xóa
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include_once __DIR__ . '/../footer.php'; ?>
</body>
</html>
