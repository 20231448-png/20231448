<?php
require '../db.php';
$cakes = $pdo->query('SELECT * FROM cakes')->fetchAll();
?>


<h2>DANH SÁCH BÁNH</h2>
<a href="admin_add.php">+ Thêm bánh</a>
<table border="1" cellpadding="10">
<tr>
<th>ID</th><th>Tên</th><th>Giá</th><th>Ảnh</th><th>Hành động</th>
</tr>
<?php foreach ($cakes as $cake): ?>
<tr>
<td><?= $cake['id'] ?></td>
<td><?= $cake['name'] ?></td>
<td><?= number_format($cake['price']) ?> đ</td>
<td><img src="../uploads/<?= $cake['image'] ?>" width="80"></td>
<td>
<a href="admin_edit.php?id=<?= $cake['id'] ?>">Sửa</a> |
<a href="admin_delete.php?id=<?= $cake['id'] ?>" onclick="return confirm('Xóa?')">Xóa</a>
</td>
</tr>
<?php endforeach ?>
</table>