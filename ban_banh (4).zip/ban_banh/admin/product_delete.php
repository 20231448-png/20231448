<?php
require '../db.php';

$id = $_GET['id'];

$pdo->prepare("DELETE FROM cakes WHERE id=?")->execute([$id]);

header("Location: products.php");
