<?php
session_start();
require '../db.php';

if ($_POST) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username=?");
    $stmt->execute([$_POST['username']]);
    $u = $stmt->fetch();

    if ($u && password_verify($_POST['password'], $u['password'])) {
        $_SESSION['admin'] = $u['username'];
        header("Location: dashboard.php");
    } else {
        echo "Sai đăng nhập";
    }
}
?>
<form method="post">
    User: <input name="username"><br>
    Pass: <input type="password" name="password"><br>
    <button>Login</button>
</form>
