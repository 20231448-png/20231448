<?php
require '../db.php';


if (isset($_POST['submit'])) {
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];


// XỬ LÝ ẢNH
$imageName = $_FILES['image']['name'];
$tmpName = $_FILES['image']['tmp_name'];


$ext = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
$allow = ['jpg','jpeg','png','gif'];
if (!in_array($ext, $allow)) {
die('Chỉ được upload ảnh');
}


if ($_FILES['image']['size'] > 2*1024*1024) {
die('Ảnh quá lớn');
}


$newImageName = time().'_'.$imageName;
move_uploaded_file($tmpName, '../uploads/'.$newImageName);


// LƯU DB
$sql = "INSERT INTO cakes(name, price, image, description) VALUES (?,?,?,?)";
$stmt = $pdo->prepare($sql);
$stmt->execute([$name, $price, $newImageName, $description]);


header('Location: admin_list.php');
}
?>


<form method="post" enctype="multipart/form-data">
<h2>THÊM BÁNH</h2>
<input type="text" name="name" placeholder="Tên bánh" required><br>
<input type="number" name="price" placeholder="Giá" required><br>
<input type="file" name="image" required><br>
<textarea name="description" placeholder="Mô tả"></textarea><br>
<button name="submit">Thêm</button>
</form>