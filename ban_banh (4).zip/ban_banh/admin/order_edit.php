<?php
session_start();
require '../db.php';

/* ===== LẤY ID ===== */
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die('❌ ID đơn hàng không hợp lệ');
}

/* ===== LẤY ĐƠN HÀNG ===== */
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die('❌ Đơn hàng không tồn tại');
}

/* ===== CẬP NHẬT ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = trim($_POST['customer_name']);
    $total = (int)$_POST['total'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("
        UPDATE orders
        SET customer_name = ?, total = ?, status = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $customer_name,
        $total,
        $status,
        $id
    ]);

    header("Location: orders.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa đơn hàng | Admin</title>

    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<div class="admin-container">
    <h1 class="admin-title">🧾 Sửa đơn hàng #<?= $order['id'] ?></h1>

    <form method="post" class="admin-form">

        <!-- TÊN KHÁCH -->
        <div class="form-group">
            <label>Tên khách hàng</label>
            <input type="text"
                   name="customer_name"
                   value="<?= htmlspecialchars($order['customer_name'] ?? '') ?>"
                   required>
        </div>

        <!-- TỔNG TIỀN -->
        <div class="form-group">
            <label>Tổng tiền (VNĐ)</label>
            <input type="number"
                   name="total"
                   value="<?= $order['total'] ?>"
                   min="0"
                   required>
        </div>

        <!-- TRẠNG THÁI -->
        <div class="form-group">
            <label>Trạng thái</label>
            <select name="status" required>
                <option value="Đang xử lý"
                    <?= $order['status'] == 'Đang xử lý' ? 'selected' : '' ?>>
                    Đang xử lý
                </option>
                <option value="Đang giao"
                    <?= $order['status'] == 'Đang giao' ? 'selected' : '' ?>>
                    Đang giao
                </option>
                <option value="Hoàn thành"
                    <?= $order['status'] == 'Hoàn thành' ? 'selected' : '' ?>>
                    Hoàn thành
                </option>
                <option value="Đã hủy"
                    <?= $order['status'] == 'Đã hủy' ? 'selected' : '' ?>>
                    Đã hủy
                </option>
            </select>
        </div>

        <!-- ACTION -->
        <div class="form-actions">
            <button type="submit" class="btn">💾 Cập nhật</button>
            <a href="orders.php" class="btn btn-back">← Quay lại</a>
        </div>

    </form>
</div>

<?php include_once __DIR__ . '/../footer.php'; ?>

</body>
</html>
