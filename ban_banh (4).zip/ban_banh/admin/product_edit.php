<?php
session_start();
require '../db.php';

/* LẤY ID */
$id = $_GET['id'] ?? 0;

/* Lấy sản phẩm */
$stmt = $pdo->prepare("SELECT * FROM cakes WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    die('❌ Sản phẩm không tồn tại');
}

/* Lấy danh mục */
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();

/* Cập nhật */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("
        UPDATE cakes
        SET name = ?, price = ?, image = ?, description = ?, category_id = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $_POST['name'],
        $_POST['price'],
        $_POST['image'],
        $_POST['description'],
        $_POST['category_id'],
        $id
    ]);

    header("Location: products.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa sản phẩm | Admin</title>

    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<div class="admin-container">
    <h1 class="admin-title">✏️ Sửa sản phẩm</h1>

    <form method="post" class="admin-form">

        <div class="form-group">
            <label>Tên sản phẩm</label>
            <input type="text" name="name"
                   value="<?= htmlspecialchars($product['name']) ?>" required>
        </div>

        <div class="form-group">
            <label>Giá (VNĐ)</label>
            <input type="number" name="price"
                   value="<?= $product['price'] ?>" required>
        </div>

        <div class="form-group">
            <label>Tên ảnh (vd: cake.jpg)</label>
            <input type="text" name="image"
                   value="<?= htmlspecialchars($product['image']) ?>">
        </div>

        <div class="form-group">
            <label>Danh mục</label>
            <select name="category_id" required>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c['id'] ?>"
                        <?= $c['id'] == $product['category_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Mô tả sản phẩm</label>
            <textarea name="description" rows="5"><?= htmlspecialchars($product['description']) ?></textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">💾 Cập nhật</button>
            <a href="products.php" class="btn btn-back">← Quay lại</a>
        </div>

    </form>
</div>

<?php include_once __DIR__ . '/../footer.php'; ?>

</body>
</html>
