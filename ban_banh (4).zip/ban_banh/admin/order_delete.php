<?php
require '../db.php';

$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
$stmt->execute([$id]);

header('Location: orders.php');
exit;
