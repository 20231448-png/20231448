<?php
session_start();
require '../db.php';

/* CHẶN KHÔNG PHẢI ADMIN */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

/* LẤY DANH SÁCH USER */
$users = $pdo->query("
    SELECT id, username, fullname, email, role
    FROM users
    ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý tài khoản | Admin</title>
    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">

    <style>
        /* giống order admin */
        .admin-container {
            max-width: 1100px;
            margin: 30px auto;
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .admin-header h1 {
            font-size: 22px;
        }

        /* bảng */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }

        .admin-table th,
        .admin-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: center;
            vertical-align: middle;
        }

        .admin-table th {
            background: #f5f6fa;
            font-weight: 600;
        }

        /* badge quyền */
        .badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .badge-admin {
            background: #ffecec;
            color: #e74c3c;
        }

        .badge-user {
            background: #eaf3ff;
            color: #3498db;
        }

        /* nút thao tác */
        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .btn-edit,
        .btn-delete {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            text-decoration: none;
            color: #fff;
            white-space: nowrap;
        }

        .btn-edit {
            background: #3498db;
        }

        .btn-edit:hover {
            background: #2980b9;
        }

        .btn-delete {
            background: #e74c3c;
        }

        .btn-delete:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<div class="admin-container">
    <div class="admin-header">
        <h1>👤 Quản lý tài khoản</h1>
        <a href="user_add.php" class="btn">➕ Thêm tài khoản</a>
    </div>

    <table class="admin-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Họ tên</th>
            <th>Email</th>
            <th>Quyền</th>
            <th width="150">Thao tác</th>
        </tr>
        </thead>

        <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
            <td>#<?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['username']) ?></td>
            <td><?= htmlspecialchars($u['fullname'] ?: '—') ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td>
                <span class="badge <?= $u['role'] === 'admin' ? 'badge-admin' : 'badge-user' ?>">
                    <?= strtoupper($u['role']) ?>
                </span>
            </td>
            <td>
                <div class="action-buttons">
                    <a href="user_edit.php?id=<?= $u['id'] ?>" class="btn-edit">Sửa</a>

                    <?php if ($u['id'] != $_SESSION['user']['id']): ?>
                    <a href="user_delete.php?id=<?= $u['id'] ?>"
                       class="btn-delete"
                       onclick="return confirm('Xóa tài khoản này?')">
                        Xóa
                    </a>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include_once __DIR__ . '/../footer.php'; ?>
</body>
</html>
