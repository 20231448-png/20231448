<?php
session_start();
require '../db.php';

/* CHẶN KHÔNG PHẢI ADMIN */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: users.php");
    exit;
}

/* LẤY USER */
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: users.php");
    exit;
}

$error = '';
$isSelf = ($_SESSION['user']['id'] == $user['id']);

/* UPDATE */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $fullname = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $role     = $_POST['role'];
    $password = $_POST['password'];

    if ($username === '' || $email === '') {
        $error = 'Vui lòng nhập đầy đủ thông tin';
    } else {
        /* check trùng username */
        $check = $pdo->prepare("
            SELECT id FROM users WHERE username = ? AND id != ?
        ");
        $check->execute([$username, $id]);

        if ($check->fetch()) {
            $error = 'Username đã tồn tại';
        } else {

            /* không cho admin tự hạ quyền */
            if ($isSelf) {
                $role = 'admin';
            }

            if ($password !== '') {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    UPDATE users
                    SET username=?, fullname=?, email=?, password=?, role=?
                    WHERE id=?
                ");
                $stmt->execute([$username, $fullname, $email, $hash, $role, $id]);
            } else {
                $stmt = $pdo->prepare("
                    UPDATE users
                    SET username=?, fullname=?, email=?, role=?
                    WHERE id=?
                ");
                $stmt->execute([$username, $fullname, $email, $role, $id]);
            }

            header("Location: users.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa tài khoản | Admin</title>
    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include '../header.php'; ?>

<div class="admin-container" style="max-width:700px">
    <h2 class="admin-title">✏️ Sửa tài khoản #<?= $user['id'] ?></h2>

    <?php if ($error): ?>
        <p style="color:red; margin-bottom:15px"><?= $error ?></p>
    <?php endif; ?>

    <form method="post" class="admin-form">

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username"
                   value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>

        <div class="form-group">
            <label>Họ tên</label>
            <input type="text" name="fullname"
                   value="<?= htmlspecialchars($user['fullname']) ?>">
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email"
                   value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>

        <div class="form-group">
            <label>Mật khẩu mới</label>
            <input type="password" name="password"
                   placeholder="Để trống nếu không đổi">
        </div>

        <div class="form-group">
            <label>Quyền</label>
            <select name="role" <?= $isSelf ? 'disabled' : '' ?>>
                <option value="user" <?= $user['role']=='user'?'selected':'' ?>>User</option>
                <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
            </select>
            <?php if ($isSelf): ?>
                <small style="color:#888">Bạn không thể tự hạ quyền của mình</small>
            <?php endif; ?>
        </div>

        <div class="form-actions">
            <button class="btn btn-save">💾 Cập nhật</button>
            <a href="users.php" class="btn btn-back">← Quay lại</a>
        </div>

    </form>
</div>

<?php include '../footer.php'; ?>
</body>
</html>
