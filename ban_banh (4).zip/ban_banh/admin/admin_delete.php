<?php
require '../db.php';
$id = $_GET['id'];


$stmt = $pdo->prepare('SELECT image FROM cakes WHERE id=?');
$stmt->execute([$id]);
$cake = $stmt->fetch();
unlink('../uploads/'.$cake['image']);


$pdo->prepare('DELETE FROM cakes WHERE id=?')->execute([$id]);
header('Location: admin_list.php');