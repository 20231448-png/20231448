<?php
session_start();
require '../db.php';

/* CHẶN KHÔNG PHẢI ADMIN */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

/* NGÀY CHỌN */
$date = $_GET['date'] ?? date('Y-m-d');

/* ===== LẤY ĐƠN HÀNG ===== */
$stmt = $pdo->prepare("
    SELECT id, customer_name, total, ship_fee, created_at
    FROM orders
    WHERE DATE(created_at) = ?
    ORDER BY created_at DESC
");
$stmt->execute([$date]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ===== TỔNG DOANH THU ===== */
$totalRevenue = 0;
foreach ($orders as $o) {
    $totalRevenue += $o['total'] + $o['ship_fee'];
}

/* ===== DOANH THU THEO GIỜ ===== */
$chartStmt = $pdo->prepare("
    SELECT 
        HOUR(created_at) AS hour,
        SUM(total + ship_fee) AS revenue
    FROM orders
    WHERE DATE(created_at) = ?
    GROUP BY HOUR(created_at)
    ORDER BY hour
");
$chartStmt->execute([$date]);
$chartData = $chartStmt->fetchAll(PDO::FETCH_ASSOC);

/* Chuẩn hóa đủ 24h */
$labels = [];
$data = array_fill(0, 24, 0);

for ($i = 0; $i < 24; $i++) {
    $labels[] = $i . ':00';
}

foreach ($chartData as $row) {
    $data[(int)$row['hour']] = (int)$row['revenue'];
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Báo cáo doanh thu | Admin</title>

    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<!-- ===== ADMIN WRAPPER ===== -->
<section class="admin-wrapper">
    <div class="admin-box">

        <!-- HEADER -->
        <div class="admin-header">
            <h1>📈 Báo cáo doanh thu theo ngày</h1>

            <form method="get" class="admin-filter">
                <input type="date" name="date" value="<?= $date ?>">
                <button class="btn">Xem</button>
            </form>
        </div>

        <!-- TỔNG DOANH THU -->
        <p style="margin:15px 0;font-size:18px;">
            <strong>Tổng doanh thu:</strong>
            <span class="price"><?= number_format($totalRevenue) ?> đ</span>
        </p>

        <!-- BIỂU ĐỒ -->
        <div style="margin:25px 0;">
            <canvas id="revenueChart" height="120"></canvas>
        </div>

        <!-- BẢNG CHI TIẾT -->
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Khách hàng</th>
                        <th>Tổng tiền</th>
                        <th>Thời gian</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($orders)): ?>
                    <tr>
                        <td colspan="4">Không có đơn hàng trong ngày</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $o): ?>
                    <tr>
                        <td>#<?= $o['id'] ?></td>
                        <td><?= htmlspecialchars($o['customer_name'] ?: 'Khách vãng lai') ?></td>
                        <td class="price">
                            <?= number_format($o['total'] + $o['ship_fee']) ?> đ
                        </td>
                        <td><?= date('d/m/Y H:i', strtotime($o['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</section>

<?php include_once __DIR__ . '/../footer.php'; ?>

<!-- SCRIPT BIỂU ĐỒ -->
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Doanh thu (VNĐ)',
            data: <?= json_encode($data) ?>,
            borderWidth: 3,
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: value => value.toLocaleString() + ' đ'
                }
            }
        }
    }
});
</script>

</body>
</html>
