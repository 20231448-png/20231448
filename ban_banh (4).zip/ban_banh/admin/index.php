<?php
session_start();
require '../db.php';

/* ===== CHECK ADMIN ===== */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

/* ===== THỐNG KÊ ===== */
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

$totalRevenue = $pdo->query("
    SELECT IFNULL(SUM(total + ship_fee),0) 
    FROM orders
")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | Bài Tập Bakery</title>

    <!-- CSS -->
    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<div class="admin-container">
    <h1 class="admin-title">📊 Bảng điều khiển Admin</h1>

    <div class="dashboard">
        <div class="dashboard-card">
            <h3>Tổng đơn hàng</h3>
            <p><?= $totalOrders ?></p>
        </div>

        <div class="dashboard-card">
            <h3>Tổng doanh thu</h3>
            <p><?= number_format($totalRevenue) ?> đ</p>
        </div>

        <div class="dashboard-card">
            <h3>Quyền</h3>
            <p>Administrator</p>
        </div>
    </div>

    <div class="admin-menu">
        <a href="orders.php">📦 Đơn hàng</a>
        <a href="users.php">👤 Tài khoản</a>
        <a href="products.php">🍰 Sản phẩm</a>
        <a href="report.php">📈 Báo cáo</a>
    </div>
</div>

<?php include_once __DIR__ . '/../footer.php'; ?>

</body>
</html>
