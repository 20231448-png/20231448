<?php
require '../db.php';
$id = $_GET['id'];


$cake = $pdo->prepare('SELECT * FROM cakes WHERE id=?');
$cake->execute([$id]);
$cake = $cake->fetch();


if (isset($_POST['submit'])) {
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];
$image = $cake['image'];


if (!empty($_FILES['image']['name'])) {
unlink('../uploads/'.$image);
$image = time().'_'.$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/'.$image);
}


$sql = 'UPDATE cakes SET name=?, price=?, image=?, description=? WHERE id=?';
$stmt = $pdo->prepare($sql);
$stmt->execute([$name, $price, $image, $description, $id]);


header('Location: admin_list.php');
}
?>


<form method="post" enctype="multipart/form-data">
<input name="name" value="<?= $cake['name'] ?>"><br>
<input name="price" value="<?= $cake['price'] ?>"><br>
<img src="../uploads/<?= $cake['image'] ?>" width="100"><br>
<input type="file" name="image"><br>
<textarea name="description"><?= $cake['description'] ?></textarea><br>
<button name="submit">Cập nhật</button>
</form>