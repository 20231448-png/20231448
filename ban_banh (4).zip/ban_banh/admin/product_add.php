<?php
session_start();
require '../db.php';

/* CHECK ADMIN */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$categories = $pdo->query("SELECT * FROM categories")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("
        INSERT INTO cakes (name, price, image, description, category_id)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_POST['name'],
        $_POST['price'],
        $_POST['image'],
        $_POST['description'],
        $_POST['category_id']
    ]);

    header("Location: products.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm sản phẩm | Admin</title>

    <link rel="stylesheet" href="/ban_banh/css/style.css">
    <link rel="stylesheet" href="/ban_banh/css/admin.css">
</head>
<body>

<?php include_once __DIR__ . '/../header.php'; ?>

<div class="admin-container">
    <h1 class="admin-title">➕ Thêm sản phẩm mới</h1>

    <form method="post" class="admin-form">

        <div class="form-group">
            <label>Tên sản phẩm</label>
            <input type="text" name="name" required>
        </div>

        <div class="form-group">
            <label>Giá (VNĐ)</label>
            <input type="number" name="price" required>
        </div>

        <div class="form-group">
            <label>Tên ảnh (vd: cake.jpg)</label>
            <input type="text" name="image">
        </div>

        <div class="form-group">
            <label>Danh mục</label>
            <select name="category_id" required>
                <option value="">-- Chọn danh mục --</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c['id'] ?>">
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Mô tả sản phẩm</label>
            <textarea name="description" rows="5"></textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">💾 Lưu sản phẩm</button>
            <a href="products.php" class="btn btn-back">← Quay lại</a>
        </div>
    </form>
</div>

<?php include_once __DIR__ . '/../footer.php'; ?>

</body>
</html>
