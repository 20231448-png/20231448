<?php
require 'db.php';

$q = $_GET['q'] ?? '';
$q = trim($q);

$cakes = [];

if ($q !== '') {
    $stmt = $pdo->prepare("
        SELECT * FROM cakes
        WHERE name LIKE ?
        ORDER BY id DESC
    ");
    $stmt->execute(['%' . $q . '%']);
    $cakes = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tìm kiếm</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="products container">
    <h2>Kết quả tìm kiếm cho: <strong><?= htmlspecialchars($q) ?></strong></h2>

    <?php if (empty($cakes)): ?>
        <p>Không tìm thấy sản phẩm nào 😢</p>
    <?php else: ?>
        <div class="product-grid">
            <?php foreach ($cakes as $cake): ?>
            <div class="product-card">
                <img src="images/<?= htmlspecialchars($cake['image']) ?>">
                <h3><?= htmlspecialchars($cake['name']) ?></h3>
                <p class="price"><?= number_format($cake['price']) ?> đ</p>
                <a href="product.php?id=<?= $cake['id'] ?>" class="btn">
                    Xem chi tiết
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php include 'footer.php'; ?>
</body>
</html>
