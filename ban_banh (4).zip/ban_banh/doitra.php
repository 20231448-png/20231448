<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chính sách đổi trả</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="page-banner">
    <h1>CHÍNH SÁCH ĐỔI TRẢ</h1>
</section>

<section class="container support-page">
    <h2>Quy định đổi trả</h2>

    <ol>
        <li>Đổi trả nếu bánh bị hư hỏng hoặc sai mẫu</li>
        <li>Khách hàng cần thông báo trong vòng <strong>2 giờ</strong></li>
        <li>Không áp dụng đổi trả với bánh đã sử dụng</li>
    </ol>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
