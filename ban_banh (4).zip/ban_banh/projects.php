<?php
require 'db.php';
$projects = $pdo->query("SELECT id, title, image FROM projects ORDER BY event_date DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Dự án | Anh Hòa Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="projects">
    <h2>DỰ ÁN ĐÃ THỰC HIỆN</h2>

    <div class="project-grid">
        <?php foreach ($projects as $p): ?>
        <div class="project-card">
            <img src="images/<?= htmlspecialchars($p['image']) ?>" alt="">
            <h3><?= htmlspecialchars($p['title']) ?></h3>
            <a href="project_detail.php?id=<?= $p['id'] ?>" class="btn">
                Xem chi tiết
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
