<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$cartCount = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['qty'];
    }
}
?>

<header class="header">
    <div class="header-top">
        <div class="container header-flex">

            <!-- LOGO -->
            <div class="logo">
                <a href="/ban_banh/index.php">
                    <img src="/ban_banh/images/logo.png" alt="Bai Tap Bakery">
                </a>
            </div>

            <!-- SEARCH -->
            <div class="search">
                <form action="/ban_banh/search.php" method="get">
                    <input type="text" name="q" placeholder="Tìm kiếm...">
                    <button type="submit">🔍</button>
                </form>
            </div>

            <!-- USER + CART -->
            <div class="header-info">
                <span class="hotline">📞 0389257122</span>

                <?php if (isset($_SESSION['user'])): ?>
                    <span class="user-name">
                        👤 <?= htmlspecialchars($_SESSION['user']['name']) ?>
                    </span>
                    <a href="/ban_banh/logout.php" class="btn-logout">Đăng xuất</a>
                <?php else: ?>
                    <a href="/ban_banh/login.php" class="btn-login">👤 Đăng nhập</a>
                <?php endif; ?>

                <a href="/ban_banh/cart.php" class="cart-icon">
                    🛒 <span class="cart-count"><?= $cartCount ?></span>
                </a>
            </div>

        </div>
    </div>

    <!-- MENU -->
    <nav class="menu">

        <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'): ?>
            <a href="/ban_banh/admin/index.php" class="menu-btn">
                ⚙️ Admin Panel
            </a>
        <?php endif; ?>

        <a href="/ban_banh/index.php">Trang chủ</a>
        <a href="/ban_banh/birthday_cakes.php">Bánh sinh nhật</a>
        <a href="/ban_banh/bread_cakes.php">Bánh mì & Bánh mặn</a>
        <a href="/ban_banh/cookies.php">Cookies & Minicake</a>
        <a href="/ban_banh/projects.php">Dự án</a>
        <a href="/ban_banh/news.php">Tin tức</a>
        <a href="/ban_banh/promotions.php">Khuyến mại</a>
        <a href="/ban_banh/my_orders.php">Đơn hàng của tôi</a>
    </nav>
</header>
