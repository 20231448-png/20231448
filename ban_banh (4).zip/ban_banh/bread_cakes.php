<?php
require 'db.php';
$cakes = $pdo->prepare("SELECT * FROM cakes WHERE category_id = 2 ORDER BY id DESC");
$cakes->execute();
$list = $cakes->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bánh mì & Bánh mặn | Bài Tập Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="products">
    <h2>🥖 BÁNH MÌ & BÁNH MẶN</h2>

    <div class="product-grid">
        <?php foreach ($list as $cake): ?>
        <div class="product-card">
            <img src="images/<?= htmlspecialchars($cake['image']) ?>">
            <h3><?= htmlspecialchars($cake['name']) ?></h3>
            <p class="price"><?= number_format($cake['price']) ?> đ</p>
            <a href="product.php?id=<?= $cake['id'] ?>" class="btn">Xem chi tiết</a>
        </div>
        <?php endforeach ?>
    </div>
</section>

<?php include 'footer.php'; ?>
</body>
</html>

