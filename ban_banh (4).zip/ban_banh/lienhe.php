<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Liên hệ</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="page-banner">
    <h1>LIÊN HỆ</h1>
</section>

<section class="container support-page">
    <h2>Thông tin liên hệ</h2>

    <p><strong>Bài tập Bakery</strong></p>
    <p>📍 Hà Nội</p>
    <p>📞 0389257122</p>
    <p>✉ baitapbakery@gmail.com</p>
    <p>⏰ 8:00 – 22:00</p>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
