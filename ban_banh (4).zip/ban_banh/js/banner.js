const slider = document.getElementById("slider");
const slides = document.querySelector(".slides");
const images = document.querySelectorAll(".slides img");
const dotsContainer = document.getElementById("dots");

let index = 0;
let startX = 0;
let isDragging = false;
let autoSlide;

/* ================== TẠO DOT ================== */
images.forEach((_, i) => {
    const dot = document.createElement("span");
    dot.dataset.index = i;

    if (i === 0) dot.classList.add("active");

    dot.addEventListener("click", () => {
        goToSlide(i);
    });

    dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".dots span");

/* ================== UPDATE SLIDER ================== */
function updateSlider(animate = true) {
    slides.style.transition = animate ? "transform 0.45s ease" : "none";
    slides.style.transform = `translateX(-${index * slider.offsetWidth}px)`;

    dots.forEach(dot => dot.classList.remove("active"));
    dots[index].classList.add("active");
}

/* ================== AUTO SLIDE ================== */
function startAuto() {
    autoSlide = setInterval(() => {
        index = (index + 1) % images.length;
        updateSlider();
    }, 4000);
}

function stopAuto() {
    clearInterval(autoSlide);
}

startAuto();

/* ================== DOT CLICK ================== */
function goToSlide(i) {
    stopAuto();
    index = i;
    updateSlider(true);
    startAuto();
}

/* ================== DRAG CHUỘT ================== */
slider.addEventListener("mousedown", e => {
    stopAuto();
    isDragging = true;
    startX = e.clientX;
    slides.style.transition = "none";
});

slider.addEventListener("mousemove", e => {
    if (!isDragging) return;

    const diff = e.clientX - startX;
    slides.style.transform =
        `translateX(${-index * slider.offsetWidth + diff}px)`;
});

slider.addEventListener("mouseup", e => finishDrag(e));
slider.addEventListener("mouseleave", e => finishDrag(e));

function finishDrag(e) {
    if (!isDragging) return;
    isDragging = false;

    const diff = e.clientX - startX;

    if (diff < -80 && index < images.length - 1) index++;
    if (diff > 80 && index > 0) index--;

    updateSlider(true);
    startAuto();
}

/* ================== RESIZE ================== */
window.addEventListener("resize", () => updateSlider(false));
