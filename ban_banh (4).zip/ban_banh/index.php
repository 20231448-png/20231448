<?php
require 'db.php';

/* Lấy sản phẩm mới nhất hiển thị trang chủ */
$cakes = $pdo->query(
    "SELECT * FROM cakes ORDER BY id DESC LIMIT 8"
)->fetchAll();
/* Lấy 3 tin tức mới nhất */
$newsList = $pdo->query("
    SELECT id, title, image, author, created_at, content
    FROM news
    ORDER BY created_at DESC
    LIMIT 3
")->fetchAll();


?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài Tập Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<!-- ===== BANNER ===== -->
<section class="banner">
    <div class="banner-slider" id="slider">
        <div class="slides">
            <img src="images/banner1.jpg" alt="">
            <img src="images/banner2.jpg" alt="">
            <img src="images/banner3.jpg" alt="">
        </div>
        <div class="dots" id="dots"></div>
    </div>
</section>

<script src="js/banner.js"></script>

<!-- ===== SẢN PHẨM TRANG CHỦ ===== -->
<section class="products">
    <div class="container">
        <h2>🍰 SẢN PHẨM NỔI BẬT</h2>

        <?php if (empty($cakes)): ?>
            <p style="text-align:center">Chưa có sản phẩm nào 😢</p>
        <?php else: ?>
        <div class="product-grid">
            <?php foreach ($cakes as $cake): ?>
            <div class="product-card">
                <img src="images/<?= htmlspecialchars($cake['image']) ?>" alt="">
                <h3><?= htmlspecialchars($cake['name']) ?></h3>
                <p class="price"><?= number_format($cake['price']) ?> đ</p>
                <a href="product.php?id=<?= $cake['id'] ?>" class="btn">
                    Xem chi tiết
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
<section class="news">
    <div class="container">
        <h2 class="section-title">TIN TỨC</h2>
        <p class="section-sub">NỔI BẬT NHẤT TRONG TUẦN</p>

        <div class="news-grid">

            <?php foreach ($newsList as $news): ?>
                <div class="news-card">

                    <div class="news-img">
                        <img src="images/<?= htmlspecialchars($news['image']) ?>" alt="">
                        <span class="news-date">
                            <?= date('d', strtotime($news['created_at'])) ?><br>
                            <?= date('m/Y', strtotime($news['created_at'])) ?>
                        </span>
                    </div>

                    <h3><?= htmlspecialchars($news['title']) ?></h3>

                    <p class="news-meta">
                        ✍ <?= htmlspecialchars($news['author']) ?>
                    </p>

                    <p class="news-desc">
                        <?= htmlspecialchars($news['short_desc']) ?>
                    </p>

                    <div class="news-btn-wrap">
                        <a href="news_detail.php?id=<?= $news['id'] ?>" class="news-btn">
                            Xem chi tiết →
                        </a>
                    </div>

                </div>
            <?php endforeach; ?>

        </div>
    </div>
</section>

<!-- ===== VỀ CHÚNG TÔI ===== -->
<section class="about">
    <div class="container">
        <h2 class="section-title">VỀ CHÚNG TÔI</h2>
        <p class="section-sub">CHÀO MỪNG BẠN ĐẾN ANHHOA BAKERY</p>

        <div class="about-container">
            <div class="about-img">
                <img src="images/about.jpg" alt="">
            </div>

            <div class="about-content">
                <p>
                    Bài Tập Bakery là thương hiệu bánh ngọt Pháp được thành lập từ năm 2004
                    tại Hà Nội. Trải qua hơn 20 năm phát triển, chúng tôi luôn mang đến
                    những sản phẩm bánh tươi ngon, an toàn và chất lượng cao.
                </p>
                <p>
                    Nguyên liệu được chọn lọc kỹ lưỡng, kết hợp cùng công nghệ hiện đại
                    và bàn tay khéo léo của đội ngũ thợ bánh giàu kinh nghiệm.
                </p>
                <a href="about.php" class="btn">ĐỌC THÊM</a>
            </div>
        </div>
    </div>
</section>

<!-- ===== FOOTER ===== -->
<footer class="footer">
    <div class="footer-container">

        <div class="footer-col">
            <img src="images/logo.png" class="footer-logo" alt="">
            <p>
                Bài Tập Bakery – Bánh tươi mỗi ngày, nguyên liệu chọn lọc,
                hương vị truyền thống kết hợp hiện đại.
            </p>
        </div>

        <div class="footer-col">
            <h4>SẢN PHẨM</h4>
            <ul>
                <li><a href="birthday_cakes.php">Bánh sinh nhật</a></li>
                <li><a href="bread.php">Bánh mỳ & Bánh mặn</a></li>
                <li><a href="cookies.php">Cookies & Minicake</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>HỖ TRỢ</h4>
            <ul>
                <li><a href="#">Hướng dẫn đặt hàng</a></li>
                <li><a href="#">Chính sách giao hàng</a></li>
                <li><a href="#">Chính sách đổi trả</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>LIÊN HỆ</h4>
            <p>📍 Hà Nội</p>
            <p>📞 0389257222</p>
            <p>✉️ baitapbakery@gmail.com</p>
        </div>

    </div>

    <div class="footer-bottom">
        © 2026 Bài tập Bakery. All rights reserved.
    </div>
</footer>

</body>
</html>
