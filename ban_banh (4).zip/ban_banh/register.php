<?php
require 'db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $passwordRaw = $_POST['password'];

    if ($fullname && $email && $passwordRaw) {
        $password = password_hash($passwordRaw, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            "INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)"
        );
        try {
            $stmt->execute([$fullname, $email, $password]);
            header("Location: login.php");
            exit;
        } catch (PDOException $e) {
            $error = "Email đã tồn tại!";
        }
    } else {
        $error = "Vui lòng nhập đầy đủ thông tin!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container">
    <div style="max-width:420px; margin:50px auto; text-align:center;">

        <h2>ĐĂNG KÝ TÀI KHOẢN</h2>
        <p style="color:#666; margin-bottom:20px;">
            Tạo tài khoản để mua hàng nhanh hơn
        </p>

        <?php if ($error): ?>
            <p style="color:red; margin-bottom:15px;">
                <?= $error ?>
            </p>
        <?php endif; ?>

        <form method="post" style="display:flex; flex-direction:column; gap:14px;">
            <input type="text" name="fullname" placeholder="Họ tên"
                   required style="width:100%; padding:12px;">
            <input type="email" name="email" placeholder="Email"
                   required style="width:100%; padding:12px;">
            <input type="password" name="password" placeholder="Mật khẩu"
                   required style="width:100%; padding:12px;">
            <button class="btn" style="width:100%;">Đăng ký</button>
        </form>

        <p style="margin-top:20px;">
            Đã có tài khoản?
            <a href="login.php" style="font-weight:bold;">Đăng nhập</a>
        </p>

    </div>
</section>

<?php include 'footer.php'; ?>
</body>
</html>
