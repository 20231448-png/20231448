<?php
session_start();
unset($_SESSION['cart']);
echo "Đã reset cart";
