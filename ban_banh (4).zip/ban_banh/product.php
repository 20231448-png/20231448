<?php
require 'db.php';

$id = $_GET['id'] ?? 0;

/* Lấy sản phẩm đang xem */
$stmt = $pdo->prepare("SELECT * FROM cakes WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    die("Sản phẩm không tồn tại");
}

/* Lấy sản phẩm gợi ý */
$related = $pdo->prepare("SELECT * FROM cakes WHERE id != ? ORDER BY RAND() LIMIT 4");
$related->execute([$id]);
$relatedProducts = $related->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($product['name']) ?> | Bài Tập Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<!-- ===== BANNER ===== -->
<section class="product-banner">
    <img src="images/banner1.jpg" alt="">
    <h1><?= htmlspecialchars($product['name']) ?></h1>
</section>

<!-- ===== CHI TIẾT SẢN PHẨM ===== -->
<section class="product-detail container">
    <div class="product-left">
        <img src="images/<?= htmlspecialchars($product['image']) ?>" alt="">
    </div>

    <div class="product-right">
        <h2><?= htmlspecialchars($product['name']) ?></h2>

        <p class="sku">Mã sản phẩm: SP<?= $product['id'] ?></p>

        <p class="price"><?= number_format($product['price']) ?> đ</p>

        <!-- SỐ LƯỢNG -->
        <div class="quantity">
            <span>Số lượng</span>
            <button type="button" onclick="changeQty(-1)">−</button>
            <input type="number" id="qty" value="1" min="1">
            <button type="button" onclick="changeQty(1)">+</button>
        </div>

        <!-- HÀNH ĐỘNG -->
        <div class="actions">
            <form action="cart_add.php" method="post">
                <input type="hidden" name="id" value="<?= $product['id'] ?>">
                <input type="hidden" name="qty" id="cartQty" value="1">

                <button type="submit" class="btn-cart">THÊM VÀO GIỎ</button>
                <a href="cart.php" class="btn-buy">MUA NGAY</a>
            </form>
        </div>

        <!-- MÔ TẢ -->
        <div class="desc">
            <h4>Mô tả sản phẩm</h4>
            <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
        </div>
    </div>
</section>

<!-- ===== SẢN PHẨM GỢI Ý ===== -->
<section class="products container">
    <h2>CÓ THỂ BẠN SẼ THÍCH</h2>

    <div class="product-grid">
        <?php foreach ($relatedProducts as $item): ?>
            <div class="product-card">
                <img src="images/<?= htmlspecialchars($item['image']) ?>" alt="">
                <h3><?= htmlspecialchars($item['name']) ?></h3>
                <p class="price"><?= number_format($item['price']) ?> đ</p>
                <a href="product.php?id=<?= $item['id'] ?>" class="btn">Xem chi tiết</a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php include 'footer.php'; ?>

<!-- ===== JS ===== -->
<script>
function changeQty(step) {
    const qty = document.getElementById('qty');
    const cartQty = document.getElementById('cartQty');

    let value = parseInt(qty.value) || 1;
    value += step;
    if (value < 1) value = 1;

    qty.value = value;
    cartQty.value = value;
}
</script>

</body>
</html>
