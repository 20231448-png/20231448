<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hỗ trợ khách hàng</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="page-banner">
    <h1>HỖ TRỢ KHÁCH HÀNG</h1>
</section>

<section class="container support-page">
    <h2>Hướng dẫn đặt hàng</h2>

    <ol>
        <li>Truy cập website <strong>Bài tập Bakery</strong></li>
        <li>Chọn sản phẩm bánh bạn yêu thích</li>
        <li>Nhấn <strong>Thêm vào giỏ hàng</strong></li>
        <li>Kiểm tra giỏ hàng</li>
        <li>Nhấn <strong>Thanh toán</strong></li>
        <li>Nhập thông tin nhận hàng</li>
        <li>Xác nhận đặt hàng</li>
    </ol>

    <p class="note">
        Sau khi đặt hàng thành công, nhân viên sẽ liên hệ xác nhận đơn hàng.
    </p>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
