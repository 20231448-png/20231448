<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đặt hàng thành công</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container" style="text-align:center; padding:60px 0">
    <h2>🎉 ĐẶT HÀNG THÀNH CÔNG</h2>
    <p>Cảm ơn bạn đã mua hàng tại <strong>Bài Tập Bakery</strong></p>
    <a href="index.php" class="btn">Quay về trang chủ</a>
</section>

<?php include 'footer.php'; ?>
</body>
</html>
