<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chính sách giao hàng</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="page-banner">
    <h1>CHÍNH SÁCH GIAO HÀNG</h1>
</section>

<section class="container support-page">
    <h2>Quy định giao hàng</h2>

    <ol>
        <li>Giao hàng nội thành trong 2 – 4 giờ</li>
        <li>Giao hàng ngoại thành trong ngày</li>
        <li>Phí giao hàng: <strong>30.000đ</strong></li>
        <li>Miễn phí giao hàng với đơn từ <strong>500.000đ</strong></li>
    </ol>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
