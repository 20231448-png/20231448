<?php
session_start();
require 'db.php';

/* ===== KIỂM TRA ĐĂNG NHẬP ===== */
if (!isset($_SESSION['user_id'])) {
    die("Bạn chưa đăng nhập");
}

$userId = $_SESSION['user_id'];

/* ===== LẤY GIỎ HÀNG ===== */
$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    die("Giỏ hàng trống");
}

/* ===== LẤY DỮ LIỆU FORM ===== */
$name     = trim($_POST['name'] ?? '');
$phone    = trim($_POST['phone'] ?? '');
$address  = trim($_POST['address'] ?? '');
$delivery = $_POST['delivery_method'] ?? 'store';
$total    = (int)($_POST['total'] ?? 0);

/* ===== VALIDATE ===== */
if ($name === '' || $phone === '') {
    die("Vui lòng nhập đầy đủ thông tin");
}

if ($delivery === 'ship' && $address === '') {
    die("Vui lòng nhập địa chỉ giao hàng");
}

/* ===== LƯU ĐƠN HÀNG ===== */
$stmt = $pdo->prepare("
    INSERT INTO orders
    (user_id, customer_name, phone, address, delivery_method, total)
    VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->execute([
    $userId,
    $name,
    $phone,
    $delivery === 'ship' ? $address : 'Nhận tại quầy',
    $delivery,
    $total
]);

$orderId = $pdo->lastInsertId();

/* ===== LƯU CHI TIẾT ĐƠN ===== */
$itemStmt = $pdo->prepare("
    INSERT INTO order_items (order_id, cake_id, qty, price)
    VALUES (?, ?, ?, ?)
");

foreach ($cart as $item) {
    $itemStmt->execute([
        $orderId,
        $item['id'],
        $item['qty'],
        $item['price']
    ]);
}

/* ===== XÓA GIỎ HÀNG ===== */
unset($_SESSION['cart']);

header("Location: checkout_success.php");
exit;
