<?php
require 'db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Về chúng tôi | Bài Tập Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<!-- ===== BANNER PAGE ===== -->
<section class="page-banner">
    <h1>VỀ CHÚNG TÔI</h1>
    <p>Hành trình hơn 20 năm mang bánh ngọt đến mọi nhà</p>
</section>

<!-- ===== GIỚI THIỆU ===== -->
<section class="about-page">
    <div class="container">
        <div class="about-container">
            <div class="about-img">
                <img src="images/logo.png" alt="Bài Tập Bakery">
            </div>

            <div class="about-content">
                <h2>Bài Tập BAKERY</h2>
                <p>
                    Bài Tập Bakery được thành lập từ năm 2004 tại Hà Nội, là thương hiệu
                    bánh ngọt Pháp được nhiều khách hàng tin tưởng suốt hơn 20 năm qua.
                </p>
                <p>
                    Chúng tôi luôn đặt chất lượng – an toàn – hương vị lên hàng đầu,
                    sử dụng nguyên liệu chọn lọc kỹ lưỡng và công nghệ hiện đại.
                </p>
                <p>
                    Mỗi chiếc bánh không chỉ là sản phẩm, mà còn là tâm huyết của đội
                    ngũ thợ bánh giàu kinh nghiệm.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- ===== GIÁ TRỊ CỐT LÕI ===== -->
<section class="values">
    <div class="container">
        <h2 class="section-title">GIÁ TRỊ CỐT LÕI</h2>

        <div class="values-grid">
            <div class="value-box">
                <h3>🍰 Chất lượng</h3>
                <p>Bánh tươi mỗi ngày, nguyên liệu an toàn, rõ nguồn gốc.</p>
            </div>

            <div class="value-box">
                <h3>❤️ Tận tâm</h3>
                <p>Luôn lắng nghe và phục vụ khách hàng bằng cả trái tim.</p>
            </div>

            <div class="value-box">
                <h3>✨ Sáng tạo</h3>
                <p>Không ngừng đổi mới mẫu mã, hương vị và trải nghiệm.</p>
            </div>
        </div>
    </div>
</section>

<!-- ===== CAM KẾT ===== -->
<section class="commitment">
    <div class="container">
        <h2 class="section-title">CAM KẾT CỦA CHÚNG TÔI</h2>
        <p class="section-sub">
            Mang đến cho bạn những chiếc bánh ngon – đẹp – an toàn nhất
        </p>

        <ul class="commit-list">
            <li>✔ Nguyên liệu tươi mới mỗi ngày</li>
            <li>✔ Không sử dụng chất bảo quản độc hại</li>
            <li>✔ Đổi trả nếu sản phẩm không đạt chất lượng</li>
            <li>✔ Giao hàng nhanh chóng, đúng hẹn</li>
        </ul>
    </div>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
