<?php
require 'db.php';

$stmt = $pdo->query("
    SELECT * FROM promotions 
    WHERE status = 1 
    AND CURDATE() BETWEEN start_date AND end_date
    ORDER BY start_date DESC
");
$promotions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Khuyến Mại | Anh Hòa Bakery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>
<main>
<section class="promotion container">
    <h2>KHUYẾN MẠI HIỆN CÓ</h2>

    <?php if (empty($promotions)): ?>
        <p style="text-align:center;">Hiện chưa có chương trình khuyến mại nào.</p>
    <?php else: ?>
        <?php foreach ($promotions as $item): ?>
            <div class="promotion-item">
                <h3><?= htmlspecialchars($item['title']) ?></h3>
                <p>
                    <strong>Giảm giá:</strong> <?= $item['discount'] ?>%
                </p>
                <p>
                    <?= nl2br(htmlspecialchars($item['description'])) ?>
                </p>
                <p class="date">
                    📅 Áp dụng từ <?= date('d/m/Y', strtotime($item['start_date'])) ?>
                    đến <?= date('d/m/Y', strtotime($item['end_date'])) ?>
                </p>
                <hr>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</section>
</main>
<?php include 'footer.php'; ?>

</body>
</html>
