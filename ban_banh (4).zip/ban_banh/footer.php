<!-- ===== FOOTER ===== -->
<footer class="footer">
    
    <div class="footer-container">

        <!-- LOGO + GIỚI THIỆU -->
        <div class="footer-col">
            <img src="images/logo.png" class="footer-logo">
            <p>
                Bài Tập Bakery chuyên cung cấp bánh tươi mỗi ngày,
                phục vụ tiệc, sinh nhật, sự kiện với chất lượng cao.
            </p>
        </div>

        <!-- SẢN PHẨM -->
        <div class="footer-col">
    <h4>SẢN PHẨM</h4>
    <ul>
        <li><a href="birthday_cakes.php">Bánh sinh nhật</a></li>
        <li><a href="bread_cakes.php">Bánh mì & Bánh mặn</a></li>
        <li><a href="cookies.php">Cookies & Minicake</a></li>
        <li><a href="projects.php">Dự án tiêu biểu</a></li>
    </ul>
</div>

        <!-- HỖ TRỢ -->
        <div class="footer-col">
            <h4>HỖ TRỢ KHÁCH HÀNG</h4>
            <ul>
                <li><a href="huongdan.php">Hướng dẫn đặt hàng</a></li>
                <li><a href="giaohang.php">Chính sách giao hàng</a></li>
                <li><a href="doitra.php">Chính sách đổi trả</a></li>
                <li><a href="lienhe.php">Liên hệ</a></li>

            </ul>
        </div>

        <!-- LIÊN HỆ -->
        <div class="footer-col">
            <h4>LIÊN HỆ</h4>
            <p>📍 Hà Nội, Việt Nam</p>
            <p>📞 0389257126</p>
            <p>✉️ Baitapbakery@gmail.com</p>

            <div class="social">
                <a href="#">🌐</a>
                <a href="#">📘</a>
                <a href="#">📸</a>
            </div>
        </div>

    </div>

    <div class="footer-bottom">
        © 2026 Bài Tập Bakery. All rights reserved.
    </div>
</footer>
