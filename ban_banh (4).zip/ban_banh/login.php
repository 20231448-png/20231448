<?php
session_start();
require 'db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
       $_SESSION['user_id'] = $user['id'];

            // 🔄 LƯU THÔNG TIN USER
            $_SESSION['user'] = [
                'id'   => $user['id'],
                'name' => $user['fullname'],
                'role' => $user['role']
            ];


        header("Location: index.php");
        exit;
    } else {
        $error = "Email hoặc mật khẩu không đúng!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container">
    <div style="max-width:420px; margin:50px auto; text-align:center;">

        <h2>ĐĂNG NHẬP</h2>
        <p style="color:#666; margin-bottom:20px;">
            Đăng nhập để tiếp tục mua sắm
        </p>

        <?php if ($error): ?>
            <p style="color:red; margin-bottom:15px;">
                <?= $error ?>
            </p>
        <?php endif; ?>


        <form method="post" style="display:flex; flex-direction:column; gap:14px;">
            <input type="email" name="email" placeholder="Email"
                   required style="width:100%; padding:12px;">
            <input type="password" name="password" placeholder="Mật khẩu"
                   required style="width:100%; padding:12px;">
            <button class="btn" style="width:100%;">Đăng nhập</button>
        </form>

        <p style="margin-top:20px;">
            Chưa có tài khoản?
            <a href="register.php" style="font-weight:bold;">Đăng ký</a>
        </p>

    </div>
    
</section>

<?php include 'footer.php'; ?>
</body>
</html>
