<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT id, created_at, total, status
    FROM orders
    WHERE user_id = ?
    ORDER BY id DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đơn hàng của tôi</title>
<link rel="stylesheet" href="css/style.css">

<style>
/* ===== MY ORDERS WIDE ===== */
.orders-wrap{
    max-width:1200px;
    margin:40px auto;
    padding:0 20px;
}

.orders-title{
    text-align:center;
    font-size:28px;
    margin-bottom:30px;
    color:#6b2c2c;
}

/* HEADER */
.order-head{
    display:grid;
    grid-template-columns: 1fr 2fr 2fr 2fr 1.5fr;
    background:#6b2c2c;
    color:#fff;
    padding:14px 20px;
    border-radius:12px;
    font-weight:bold;
}

/* ROW */
.order-row{
    display:grid;
    grid-template-columns: 1fr 2fr 2fr 2fr 1.5fr;
    align-items:center;
    background:#fff;
    padding:18px 20px;
    margin-top:12px;
    border-radius:14px;
    box-shadow:0 6px 20px rgba(0,0,0,0.08);
    transition:.3s;
}

.order-row:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 28px rgba(0,0,0,0.12);
}

.order-id{
    font-weight:bold;
    color:#6b2c2c;
}

.order-total{
    font-weight:bold;
    color:#d40000;
    font-size:17px;
}

.order-status{
    padding:6px 14px;
    border-radius:20px;
    display:inline-block;
    font-size:14px;
}

.st-processing{background:#fff3cd;color:#856404;}
.st-done{background:#d4edda;color:#155724;}
.st-cancel{background:#f8d7da;color:#721c24;}

.order-action a{
    padding:8px 18px;
    border-radius:20px;
    background:#6b2c2c;
    color:#fff;
    text-decoration:none;
    font-size:14px;
    transition:.3s;
}

.order-action a:hover{
    background:#8a3b3b;
}

/* EMPTY */
.no-order{
    text-align:center;
    padding:80px 20px;
    color:#666;
    font-size:16px;
}

/* MOBILE */
@media(max-width:768px){
    .order-head{display:none;}
    .order-row{
        grid-template-columns:1fr;
        gap:8px;
    }
}
</style>
</head>

<body>
<?php include 'header.php'; ?>

<section class="orders-wrap">
<h2 class="orders-title">ĐƠN HÀNG CỦA TÔI</h2>

<?php if(empty($orders)): ?>
    <div class="no-order">
        🛒 Bạn chưa có đơn hàng nào
    </div>
<?php else: ?>

<div class="order-head">
    <div>Mã đơn</div>
    <div>Ngày đặt</div>
    <div>Trạng thái</div>
    <div>Tổng tiền</div>
    <div>Chi tiết</div>
</div>

<?php foreach($orders as $order): ?>
<?php
    $stClass = 'st-processing';
    if($order['status']=='Hoàn thành') $stClass='st-done';
    if($order['status']=='Đã hủy' || $order['status']=='cancel') $stClass='st-cancel';
?>
<div class="order-row">
    <div class="order-id">#<?= $order['id'] ?></div>
    <div><?= $order['created_at'] ?></div>
    <div>
        <span class="order-status <?= $stClass ?>">
            <?= $order['status'] ?>
        </span>
    </div>
    <div class="order-total">
        <?= number_format($order['total']) ?> đ
    </div>
    <div class="order-action">
        <a href="order_detail.php?id=<?= $order['id'] ?>">
            Xem
        </a>
    </div>
</div>
<?php endforeach; ?>

<?php endif; ?>
</section>

<?php include 'footer.php'; ?>
</body>
</html>
