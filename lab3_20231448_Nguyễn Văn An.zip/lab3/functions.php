<?php
// ================== THƯ VIỆN HÀM ==================

/**
 * Trả về số lớn hơn giữa a và b
 */
function max2($a, $b) {
    if ($a > $b) return $a;
    return $b;
}

/**
 * Trả về số nhỏ hơn giữa a và b
 */
function min2($a, $b) {
    if ($a < $b) return $a;
    return $b;
}

/**
 * Kiểm tra số nguyên tố
 */
function isPrime($n) {
    if ($n < 2) return false;
    for ($i = 2; $i <= $n / 2; $i++) {
        if ($n % $i == 0) return false;
    }
    return true;
}

/**
 * Tính giai thừa
 */
function factorial($n) {
    if ($n < 0) return null;
    $f = 1;
    for ($i = 1; $i <= $n; $i++) {
        $f *= $i;
    }
    return $f;
}

/**
 * Ước chung lớn nhất (Euclid)
 */
function gcd($a, $b) {
    $a = abs($a);
    $b = abs($b);
    while ($b != 0) {
        $r = $a % $b;
        $a = $b;
        $b = $r;
    }
    return $a;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bài 4 - Functions</title>
</head>
<body>

<h2>Test hàm </h2>

<form method="get">
    a: <input type="number" name="a" required>
    b: <input type="number" name="b" required><br><br>
    n: <input type="number" name="n" required><br><br>
    <button type="submit">Chạy hàm</button>
</form>

<?php
if (isset($_GET["a"], $_GET["b"], $_GET["n"])) {
    $a = (int)$_GET["a"];
    $b = (int)$_GET["b"];
    $n = (int)$_GET["n"];

    echo "<hr>";
    echo "max2($a, $b) = " . max2($a, $b) . "<br>";
    echo "min2($a, $b) = " . min2($a, $b) . "<br>";
    echo "isPrime($n) = " . (isPrime($n) ? "true" : "false") . "<br>";
    echo "factorial($n) = ";
    var_dump(factorial($n));
    echo "<br>";
    echo "gcd($a, $b) = " . gcd($a, $b);
}
?>

</body>
</html>
