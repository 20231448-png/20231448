<?php
require_once "functions.php";

$action = $_GET["action"] ?? "home";
$a = $_GET["a"] ?? "";
$b = $_GET["b"] ?? "";
$n = $_GET["n"] ?? "";

echo "<h2>LAB03 - Mini Utility</h2>";

echo "<p>
<a href='?action=max&a=10&b=22'>Max</a> |
<a href='?action=min&a=10&b=22'>Min</a> |
<a href='?action=prime&n=17'>Prime</a> |
<a href='?action=fact&n=6'>Factorial</a> |
<a href='?action=gcd&a=12&b=18'>GCD</a>
</p>";
?>

<hr>

<h3>Test hàm (nhập tay)</h3>
<form method="get">
    <input type="hidden" name="action" value="form">
    a: <input type="number" name="a" value="<?= htmlspecialchars($a) ?>"><br><br>
    b: <input type="number" name="b" value="<?= htmlspecialchars($b) ?>"><br><br>
    n: <input type="number" name="n" value="<?= htmlspecialchars($n) ?>"><br><br>
    <button type="submit">Chạy hàm</button>
</form>

<hr>

<?php
switch ($action) {
    case "max":
        echo "Kết quả: max($a,$b) = " . max2($a, $b);
        break;

    case "min":
        echo "Kết quả: min($a,$b) = " . min2($a, $b);
        break;

    case "prime":
        echo isPrime($n) ? "$n là số nguyên tố" : "$n không phải số nguyên tố";
        break;

    case "fact":
        echo "$n! = " . factorial($n);
        break;

    case "gcd":
        echo "ƯCLN($a, $b) = " . gcd($a, $b);
        break;

    case "form":
        echo "<strong>Kết quả từ form:</strong><br>";
        if ($a !== "" && $b !== "") {
            echo "max($a,$b) = " . max2($a, $b) . "<br>";
            echo "min($a,$b) = " . min2($a, $b) . "<br>";
            echo "gcd($a,$b) = " . gcd($a, $b) . "<br>";
        }
        if ($n !== "") {
            echo "isPrime($n) = " . (isPrime($n) ? "true" : "false") . "<br>";
            echo "factorial($n) = " . factorial($n);
        }
        break;

    default:
        echo "Chọn chức năng ở menu hoặc nhập dữ liệu vào form.";
}
?>
