<?php
$a  = $_GET["a"] ?? null;
$b  = $_GET["b"] ?? null;
$op = $_GET["op"] ?? null;

$result = null;
$error = null;

if ($a !== null && $b !== null && $op !== null) {
    $a = (float)$a;
    $b = (float)$b;

    switch ($op) {
        case "add":
            $result = "$a + $b = " . ($a + $b);
            break;

        case "sub":
            $result = "$a - $b = " . ($a - $b);
            break;

        case "mul":
            $result = "$a × $b = " . ($a * $b);
            break;

        case "div":
            if ($b == 0) {
                $error = "Không chia được cho 0";
            } else {
                $result = "$a / $b = " . ($a / $b);
            }
            break;

        default:
            $error = "Phép toán không hợp lệ";
    }
}
?>

<form method="get">
    a: <input type="number" name="a" step="0.1" required>
    b: <input type="number" name="b" step="0.1" required>

    <select name="op">
        <option value="add">Cộng</option>
        <option value="sub">Trừ</option>
        <option value="mul">Nhân</option>
        <option value="div">Chia</option>
    </select>

    <button type="submit">Tính</button>
</form>

<?php
if ($error) {
    echo "<p style='color:red'>$error</p>";
}
if ($result) {
    echo "<p>$result</p>";
}
?>
