<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bài 3 - Vòng lặp</title>
    <style>
        table { border-collapse: collapse; }
        td { border: 1px solid #333; padding: 5px; text-align: center; }
    </style>
</head>
<body>

<h2>A) Bảng cửu chương 1..9 (for lồng nhau)</h2>
<table>
<?php
for ($i = 1; $i <= 9; $i++) {
    echo "<tr>";
    for ($j = 1; $j <= 9; $j++) {
        echo "<td>$i × $j = " . ($i * $j) . "</td>";
    }
    echo "</tr>";
}
?>
</table>

<hr>

<h2>B) Tính tổng chữ số của n (while)</h2>

<form method="get">
    Nhập n:
    <input type="number" name="n" required>
    <button type="submit">Tính</button>
</form>

<?php
if (isset($_GET["n"])) {
    $n = abs((int)$_GET["n"]); // lấy trị tuyệt đối
    $sum = 0;
    $temp = $n;

    while ($temp > 0) {
        $sum += $temp % 10;
        $temp = (int)($temp / 10);
    }

    echo "<p>Tổng chữ số của $n = $sum</p>";
}
?>

<hr>

<h2>C) In số lẻ từ 1..N (continue + break)</h2>

<form method="get">
    Nhập N:
    <input type="number" name="N" required>
    <button type="submit">In số</button>
</form>

<?php
if (isset($_GET["N"])) {
    $N = (int)$_GET["N"];

    echo "<p>Các số lẻ:</p>";

    for ($i = 1; $i <= $N; $i++) {

        if ($i % 2 == 0) {
            continue; // bỏ qua số chẵn
        }

        if ($i > 15) {
            break; // dừng sớm khi vượt 15
        }

        echo $i . " ";
    }
}
?>

</body>
</html>
