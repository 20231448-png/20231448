<?php
$score = $_GET["score"] ?? null;

if ($score !== null) {
    $score = (float)$score;

    if ($score < 0 || $score > 10) {
        $result = "Điểm không hợp lệ (0–10)";
    } else {
        if ($score >= 8.5) {
            $grade = "Giỏi";
        } elseif ($score >= 7.0) {
            $grade = "Khá";
        } elseif ($score >= 5.0) {
            $grade = "Trung bình";
        } else {
            $grade = "Yếu";
        }
        $result = "Điểm: $score – Xếp loại: $grade";
    }
}
?>

<form method="get">
    Nhập điểm:
    <input type="number" name="score" step="0.1" min="0" max="10">
    <button type="submit">Xếp loại</button>
</form>

<?php
if (isset($result)) {
    echo "<p>$result</p>";
}
?>
