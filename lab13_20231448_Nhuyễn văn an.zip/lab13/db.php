<?php
$conn = new mysqli("localhost", "root", "", "mini_inventory", 3307);

if ($conn->connect_error) {
    die("Lỗi kết nối CSDL: " . $conn->connect_error);
}
?>
