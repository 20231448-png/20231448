<?php
require 'db.php';

/* THÊM SẢN PHẨM */
if (isset($_POST['add'])) {
    $code  = $_POST['code'];
    $name  = $_POST['name'];
    $price = $_POST['price'];

    $conn->query("INSERT INTO products(code,name,price)
                  VALUES('$code','$name',$price)");
}

/* LẤY DANH SÁCH */
$result = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý sản phẩm</title>
</head>
<body>

<h2>➕ Thêm sản phẩm</h2>
<form method="post">
    Mã: <input name="code" required>
    Tên: <input name="name" required>
    Giá: <input name="price" type="number" required>
    <button name="add">Thêm</button>
</form>

<hr>

<h2>📦 Danh sách sản phẩm</h2>
<table border="1" cellpadding="5">
<tr>
    <th>ID</th>
    <th>Mã</th>
    <th>Tên</th>
    <th>Giá</th>
    <th>Xoá</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['code'] ?></td>
    <td><?= $row['name'] ?></td>
    <td><?= number_format($row['price']) ?></td>
    <td>
        <a href="delete.php?id=<?= $row['id'] ?>"
           onclick="return confirm('Xoá sản phẩm?')">
           ❌
        </a>
    </td>
</tr>
<?php } ?>

</table>

</body>
</html>
